Invoices, Payments and Late Payers
Invoices, payments, reminders and late payers for cleaning businesses

FILES
  Invoices-Payments-and-Late-Payers_EN.xlsx   English
  Invoices-Payments-and-Late-Payers_AR.xlsx   العربية
  Invoices-Payments-and-Late-Payers_FR.xlsx   Français
  Invoices-Payments-and-Late-Payers_ES.xlsx   Español
  Invoices-Payments-and-Late-Payers_DE.xlsx   Deutsch
  Invoices-Payments-and-Late-Payers_IT.xlsx   Italiano
  Invoices-Payments-and-Late-Payers_PT.xlsx   Português
  Invoices-Payments-and-Late-Payers_TR.xlsx   Türkçe
  Invoices-Payments-and-Late-Payers_NL.xlsx   Nederlands
  Invoices-Payments-and-Late-Payers_RU.xlsx   Русский
  Invoices-Payments-and-Late-Payers_FA.xlsx   فارسی
  Invoices-Payments-and-Late-Payers_UR.xlsx   اردو
  Invoices-Payments-and-Late-Payers_HI.xlsx   हिन्दी
  Invoices-Payments-and-Late-Payers_ZH.xlsx   中文
  Invoices-Payments-and-Late-Payers_ID.xlsx   Bahasa Indonesia
  Invoices-Payments-and-Late-Payers_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
