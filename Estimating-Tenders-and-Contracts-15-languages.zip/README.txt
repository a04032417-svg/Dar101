Estimating, Tenders and Contracts
Price tenders, compare quotes and control contracts

FILES
  Estimating-Tenders-and-Contracts_EN.xlsx   English
  Estimating-Tenders-and-Contracts_AR.xlsx   العربية
  Estimating-Tenders-and-Contracts_FR.xlsx   Français
  Estimating-Tenders-and-Contracts_ES.xlsx   Español
  Estimating-Tenders-and-Contracts_DE.xlsx   Deutsch
  Estimating-Tenders-and-Contracts_IT.xlsx   Italiano
  Estimating-Tenders-and-Contracts_PT.xlsx   Português
  Estimating-Tenders-and-Contracts_TR.xlsx   Türkçe
  Estimating-Tenders-and-Contracts_NL.xlsx   Nederlands
  Estimating-Tenders-and-Contracts_RU.xlsx   Русский
  Estimating-Tenders-and-Contracts_FA.xlsx   فارسی
  Estimating-Tenders-and-Contracts_UR.xlsx   اردو
  Estimating-Tenders-and-Contracts_HI.xlsx   हिन्दी
  Estimating-Tenders-and-Contracts_ZH.xlsx   中文
  Estimating-Tenders-and-Contracts_ID.xlsx   Bahasa Indonesia
  Estimating-Tenders-and-Contracts_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
