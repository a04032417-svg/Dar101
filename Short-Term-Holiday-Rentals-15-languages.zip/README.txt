Short-Term & Holiday Rentals
Bookings, channels, pricing, cleaning and owner payouts for holiday homes

FILES
  Short-Term-Holiday-Rentals_EN.xlsx   English
  Short-Term-Holiday-Rentals_AR.xlsx   العربية
  Short-Term-Holiday-Rentals_FR.xlsx   Français
  Short-Term-Holiday-Rentals_ES.xlsx   Español
  Short-Term-Holiday-Rentals_DE.xlsx   Deutsch
  Short-Term-Holiday-Rentals_IT.xlsx   Italiano
  Short-Term-Holiday-Rentals_PT.xlsx   Português
  Short-Term-Holiday-Rentals_TR.xlsx   Türkçe
  Short-Term-Holiday-Rentals_NL.xlsx   Nederlands
  Short-Term-Holiday-Rentals_RU.xlsx   Русский
  Short-Term-Holiday-Rentals_FA.xlsx   فارسی
  Short-Term-Holiday-Rentals_UR.xlsx   اردو
  Short-Term-Holiday-Rentals_HI.xlsx   हिन्दी
  Short-Term-Holiday-Rentals_ZH.xlsx   中文
  Short-Term-Holiday-Rentals_ID.xlsx   Bahasa Indonesia
  Short-Term-Holiday-Rentals_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
