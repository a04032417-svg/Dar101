Procurement and Purchase Orders
Order everything your clients approved, on time and at the right price

FILES
  Procurement-and-Purchase-Orders_EN.xlsx   English
  Procurement-and-Purchase-Orders_AR.xlsx   العربية
  Procurement-and-Purchase-Orders_FR.xlsx   Français
  Procurement-and-Purchase-Orders_ES.xlsx   Español
  Procurement-and-Purchase-Orders_DE.xlsx   Deutsch
  Procurement-and-Purchase-Orders_IT.xlsx   Italiano
  Procurement-and-Purchase-Orders_PT.xlsx   Português
  Procurement-and-Purchase-Orders_TR.xlsx   Türkçe
  Procurement-and-Purchase-Orders_NL.xlsx   Nederlands
  Procurement-and-Purchase-Orders_RU.xlsx   Русский
  Procurement-and-Purchase-Orders_FA.xlsx   فارسی
  Procurement-and-Purchase-Orders_UR.xlsx   اردو
  Procurement-and-Purchase-Orders_HI.xlsx   हिन्दी
  Procurement-and-Purchase-Orders_ZH.xlsx   中文
  Procurement-and-Purchase-Orders_ID.xlsx   Bahasa Indonesia
  Procurement-and-Purchase-Orders_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
