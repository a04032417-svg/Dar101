Deliveries, Installation and Punch Lists
Get every delivery into the room and every project handed over

FILES
  Deliveries-Installation-and-Punch-Lists_EN.xlsx   English
  Deliveries-Installation-and-Punch-Lists_AR.xlsx   العربية
  Deliveries-Installation-and-Punch-Lists_FR.xlsx   Français
  Deliveries-Installation-and-Punch-Lists_ES.xlsx   Español
  Deliveries-Installation-and-Punch-Lists_DE.xlsx   Deutsch
  Deliveries-Installation-and-Punch-Lists_IT.xlsx   Italiano
  Deliveries-Installation-and-Punch-Lists_PT.xlsx   Português
  Deliveries-Installation-and-Punch-Lists_TR.xlsx   Türkçe
  Deliveries-Installation-and-Punch-Lists_NL.xlsx   Nederlands
  Deliveries-Installation-and-Punch-Lists_RU.xlsx   Русский
  Deliveries-Installation-and-Punch-Lists_FA.xlsx   فارسی
  Deliveries-Installation-and-Punch-Lists_UR.xlsx   اردو
  Deliveries-Installation-and-Punch-Lists_HI.xlsx   हिन्दी
  Deliveries-Installation-and-Punch-Lists_ZH.xlsx   中文
  Deliveries-Installation-and-Punch-Lists_ID.xlsx   Bahasa Indonesia
  Deliveries-Installation-and-Punch-Lists_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
