Interior Designer Business Suite
Know what every project really earns – and stop FF&E orders eating your margin

WORKBOOKS
  01 - Enquiries, Proposals and Design Fees: Turn enquiries into signed projects at a fee that pays
  02 - Projects, Phases and Approvals: Phases, approvals, hours and margin for every design project
  03 - FF&E Schedules and Room Budgets: Specify every item and keep every room on budget
  04 - Procurement and Purchase Orders: Order everything your clients approved, on time and at the right price
  05 - Deliveries, Installation and Punch Lists: Get every delivery into the room and every project handed over
  06 - Time, Billing, Retainers and Invoices: Get paid for your time and your product, on time
  07 - Vendors, Trades and Contractors: Know which vendors and contractors deserve your next order
  08 - Finance, Cash Flow and Growth: Know what your studio really earns and what is coming

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
