Utilisation, Profit and Pricing
See profit per vehicle, idle days and which cars to keep, reprice or sell

FILES
  Utilisation-Profit-and-Pricing_EN.xlsx   the workbook in English
  Utilisation-Profit-and-Pricing_EN_DEMO-sample-data.xlsx   the same workbook filled with sample data (English)
  Utilisation-Profit-and-Pricing_AR.xlsx   the workbook in Arabic
  Utilisation-Profit-and-Pricing_AR_DEMO-sample-data.xlsx   the same workbook filled with sample data (Arabic)

HOW TO START
  1. Open the file and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel, Google Sheets and LibreOffice Calc. No macros.
  Google Sheets: upload the file to Google Drive and open it with Google Sheets, or use the copy link in your download.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.

بالعربية
  Utilisation-Profit-and-Pricing_AR.xlsx   ملف العمل باللغة العربية
  Utilisation-Profit-and-Pricing_AR_DEMO-sample-data.xlsx   الملف نفسه مملوءاً ببيانات تجريبية لترى كل ميزة وهي تعمل
  ابدأ بالورقة الأولى: اكتب إعداداتك في الخانات الصفراء، ثم بياناتك في الخانات البيضاء؛ الخانات الرمادية تُحسب وحدها.
  الملفات بصيغة xlsx وتعمل في Excel وGoogle Sheets وLibreOffice، بلا وحدات ماكرو.
