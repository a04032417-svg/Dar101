Materials, Procurement and Equipment
Control materials, suppliers and machines

FILES
  Materials-Procurement-and-Equipment_EN.xlsx   English
  Materials-Procurement-and-Equipment_AR.xlsx   العربية
  Materials-Procurement-and-Equipment_FR.xlsx   Français
  Materials-Procurement-and-Equipment_ES.xlsx   Español
  Materials-Procurement-and-Equipment_DE.xlsx   Deutsch
  Materials-Procurement-and-Equipment_IT.xlsx   Italiano
  Materials-Procurement-and-Equipment_PT.xlsx   Português
  Materials-Procurement-and-Equipment_TR.xlsx   Türkçe
  Materials-Procurement-and-Equipment_NL.xlsx   Nederlands
  Materials-Procurement-and-Equipment_RU.xlsx   Русский
  Materials-Procurement-and-Equipment_FA.xlsx   فارسی
  Materials-Procurement-and-Equipment_UR.xlsx   اردو
  Materials-Procurement-and-Equipment_HI.xlsx   हिन्दी
  Materials-Procurement-and-Equipment_ZH.xlsx   中文
  Materials-Procurement-and-Equipment_ID.xlsx   Bahasa Indonesia
  Materials-Procurement-and-Equipment_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
