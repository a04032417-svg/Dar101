Reporting and Advisory
Management reports, budgets, loan checks and advice for every client in one file

FILES
  Reporting-and-Advisory_EN.xlsx   English
  Reporting-and-Advisory_AR.xlsx   العربية
  Reporting-and-Advisory_FR.xlsx   Français
  Reporting-and-Advisory_ES.xlsx   Español
  Reporting-and-Advisory_DE.xlsx   Deutsch
  Reporting-and-Advisory_IT.xlsx   Italiano
  Reporting-and-Advisory_PT.xlsx   Português
  Reporting-and-Advisory_TR.xlsx   Türkçe
  Reporting-and-Advisory_NL.xlsx   Nederlands
  Reporting-and-Advisory_RU.xlsx   Русский
  Reporting-and-Advisory_FA.xlsx   فارسی
  Reporting-and-Advisory_UR.xlsx   اردو
  Reporting-and-Advisory_HI.xlsx   हिन्दी
  Reporting-and-Advisory_ZH.xlsx   中文
  Reporting-and-Advisory_ID.xlsx   Bahasa Indonesia
  Reporting-and-Advisory_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
