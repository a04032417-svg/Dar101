Deal Analysis and Pipeline
Deal analysis, offers, due diligence and loan quotes for real estate investors

FILES
  Deal-Analysis-and-Pipeline_EN.xlsx   English
  Deal-Analysis-and-Pipeline_AR.xlsx   العربية
  Deal-Analysis-and-Pipeline_FR.xlsx   Français
  Deal-Analysis-and-Pipeline_ES.xlsx   Español
  Deal-Analysis-and-Pipeline_DE.xlsx   Deutsch
  Deal-Analysis-and-Pipeline_IT.xlsx   Italiano
  Deal-Analysis-and-Pipeline_PT.xlsx   Português
  Deal-Analysis-and-Pipeline_TR.xlsx   Türkçe
  Deal-Analysis-and-Pipeline_NL.xlsx   Nederlands
  Deal-Analysis-and-Pipeline_RU.xlsx   Русский
  Deal-Analysis-and-Pipeline_FA.xlsx   فارسی
  Deal-Analysis-and-Pipeline_UR.xlsx   اردو
  Deal-Analysis-and-Pipeline_HI.xlsx   हिन्दी
  Deal-Analysis-and-Pipeline_ZH.xlsx   中文
  Deal-Analysis-and-Pipeline_ID.xlsx   Bahasa Indonesia
  Deal-Analysis-and-Pipeline_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
