Cash Flow, Reserves and Growth
Cash forecast, reserves, owner draw and growth targets for your portfolio

FILES
  Cash-Flow-Reserves-and-Growth_EN.xlsx   English
  Cash-Flow-Reserves-and-Growth_AR.xlsx   العربية
  Cash-Flow-Reserves-and-Growth_FR.xlsx   Français
  Cash-Flow-Reserves-and-Growth_ES.xlsx   Español
  Cash-Flow-Reserves-and-Growth_DE.xlsx   Deutsch
  Cash-Flow-Reserves-and-Growth_IT.xlsx   Italiano
  Cash-Flow-Reserves-and-Growth_PT.xlsx   Português
  Cash-Flow-Reserves-and-Growth_TR.xlsx   Türkçe
  Cash-Flow-Reserves-and-Growth_NL.xlsx   Nederlands
  Cash-Flow-Reserves-and-Growth_RU.xlsx   Русский
  Cash-Flow-Reserves-and-Growth_FA.xlsx   فارسی
  Cash-Flow-Reserves-and-Growth_UR.xlsx   اردو
  Cash-Flow-Reserves-and-Growth_HI.xlsx   हिन्दी
  Cash-Flow-Reserves-and-Growth_ZH.xlsx   中文
  Cash-Flow-Reserves-and-Growth_ID.xlsx   Bahasa Indonesia
  Cash-Flow-Reserves-and-Growth_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
