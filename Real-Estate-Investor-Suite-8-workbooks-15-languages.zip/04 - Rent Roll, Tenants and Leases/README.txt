Rent Roll, Tenants and Leases
Rent roll, tenants, leases, arrears and vacancy for real estate investors

FILES
  Rent-Roll-Tenants-and-Leases_EN.xlsx   English
  Rent-Roll-Tenants-and-Leases_AR.xlsx   العربية
  Rent-Roll-Tenants-and-Leases_FR.xlsx   Français
  Rent-Roll-Tenants-and-Leases_ES.xlsx   Español
  Rent-Roll-Tenants-and-Leases_DE.xlsx   Deutsch
  Rent-Roll-Tenants-and-Leases_IT.xlsx   Italiano
  Rent-Roll-Tenants-and-Leases_PT.xlsx   Português
  Rent-Roll-Tenants-and-Leases_TR.xlsx   Türkçe
  Rent-Roll-Tenants-and-Leases_NL.xlsx   Nederlands
  Rent-Roll-Tenants-and-Leases_RU.xlsx   Русский
  Rent-Roll-Tenants-and-Leases_FA.xlsx   فارسی
  Rent-Roll-Tenants-and-Leases_UR.xlsx   اردو
  Rent-Roll-Tenants-and-Leases_HI.xlsx   हिन्दी
  Rent-Roll-Tenants-and-Leases_ZH.xlsx   中文
  Rent-Roll-Tenants-and-Leases_ID.xlsx   Bahasa Indonesia
  Rent-Roll-Tenants-and-Leases_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
