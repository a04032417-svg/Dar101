Maintenance, Capex and Insurance
Work orders, capex reserve, insurance and tax bills for real estate investors

FILES
  Maintenance-Capex-and-Insurance_EN.xlsx   English
  Maintenance-Capex-and-Insurance_AR.xlsx   العربية
  Maintenance-Capex-and-Insurance_FR.xlsx   Français
  Maintenance-Capex-and-Insurance_ES.xlsx   Español
  Maintenance-Capex-and-Insurance_DE.xlsx   Deutsch
  Maintenance-Capex-and-Insurance_IT.xlsx   Italiano
  Maintenance-Capex-and-Insurance_PT.xlsx   Português
  Maintenance-Capex-and-Insurance_TR.xlsx   Türkçe
  Maintenance-Capex-and-Insurance_NL.xlsx   Nederlands
  Maintenance-Capex-and-Insurance_RU.xlsx   Русский
  Maintenance-Capex-and-Insurance_FA.xlsx   فارسی
  Maintenance-Capex-and-Insurance_UR.xlsx   اردو
  Maintenance-Capex-and-Insurance_HI.xlsx   हिन्दी
  Maintenance-Capex-and-Insurance_ZH.xlsx   中文
  Maintenance-Capex-and-Insurance_ID.xlsx   Bahasa Indonesia
  Maintenance-Capex-and-Insurance_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
