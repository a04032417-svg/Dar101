Financing, Loans and Refinance
Loans, balloon dates, refinance and debt coverage for real estate investors

FILES
  Financing-Loans-and-Refinance_EN.xlsx   English
  Financing-Loans-and-Refinance_AR.xlsx   العربية
  Financing-Loans-and-Refinance_FR.xlsx   Français
  Financing-Loans-and-Refinance_ES.xlsx   Español
  Financing-Loans-and-Refinance_DE.xlsx   Deutsch
  Financing-Loans-and-Refinance_IT.xlsx   Italiano
  Financing-Loans-and-Refinance_PT.xlsx   Português
  Financing-Loans-and-Refinance_TR.xlsx   Türkçe
  Financing-Loans-and-Refinance_NL.xlsx   Nederlands
  Financing-Loans-and-Refinance_RU.xlsx   Русский
  Financing-Loans-and-Refinance_FA.xlsx   فارسی
  Financing-Loans-and-Refinance_UR.xlsx   اردو
  Financing-Loans-and-Refinance_HI.xlsx   हिन्दी
  Financing-Loans-and-Refinance_ZH.xlsx   中文
  Financing-Loans-and-Refinance_ID.xlsx   Bahasa Indonesia
  Financing-Loans-and-Refinance_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
