Real Estate Investor Suite
Buy the right deals, see which properties pay and never run short of cash

WORKBOOKS
  01 - Deal Analysis and Pipeline: Deal analysis, offers, due diligence and loan quotes for real estate investors
  02 - Financing, Loans and Refinance: Loans, balloon dates, refinance and debt coverage for real estate investors
  03 - Renovation Budgets and Draws: Rehab budgets, contractor draws and flip profit for real estate investors
  04 - Rent Roll, Tenants and Leases: Rent roll, tenants, leases, arrears and vacancy for real estate investors
  05 - Maintenance, Capex and Insurance: Work orders, capex reserve, insurance and tax bills for real estate investors
  06 - Property Performance and Underwriting: NOI, cap rate, cash-on-cash and DSCR for every rental property
  07 - Net Worth, Taxes and Exit Planning: Net worth, cost basis, depreciation and exit planning for your portfolio
  08 - Cash Flow, Reserves and Growth: Cash forecast, reserves, owner draw and growth targets for your portfolio

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
