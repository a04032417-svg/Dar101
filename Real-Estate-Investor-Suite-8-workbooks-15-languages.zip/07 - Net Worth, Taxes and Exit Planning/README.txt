Net Worth, Taxes and Exit Planning
Net worth, cost basis, depreciation and exit planning for your portfolio

FILES
  Net-Worth-Taxes-and-Exit-Planning_EN.xlsx   English
  Net-Worth-Taxes-and-Exit-Planning_AR.xlsx   العربية
  Net-Worth-Taxes-and-Exit-Planning_FR.xlsx   Français
  Net-Worth-Taxes-and-Exit-Planning_ES.xlsx   Español
  Net-Worth-Taxes-and-Exit-Planning_DE.xlsx   Deutsch
  Net-Worth-Taxes-and-Exit-Planning_IT.xlsx   Italiano
  Net-Worth-Taxes-and-Exit-Planning_PT.xlsx   Português
  Net-Worth-Taxes-and-Exit-Planning_TR.xlsx   Türkçe
  Net-Worth-Taxes-and-Exit-Planning_NL.xlsx   Nederlands
  Net-Worth-Taxes-and-Exit-Planning_RU.xlsx   Русский
  Net-Worth-Taxes-and-Exit-Planning_FA.xlsx   فارسی
  Net-Worth-Taxes-and-Exit-Planning_UR.xlsx   اردو
  Net-Worth-Taxes-and-Exit-Planning_HI.xlsx   हिन्दी
  Net-Worth-Taxes-and-Exit-Planning_ZH.xlsx   中文
  Net-Worth-Taxes-and-Exit-Planning_ID.xlsx   Bahasa Indonesia
  Net-Worth-Taxes-and-Exit-Planning_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
