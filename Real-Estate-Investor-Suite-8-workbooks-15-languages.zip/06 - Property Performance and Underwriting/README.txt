Property Performance and Underwriting
NOI, cap rate, cash-on-cash and DSCR for every rental property

FILES
  Property-Performance-and-Underwriting_EN.xlsx   English
  Property-Performance-and-Underwriting_AR.xlsx   العربية
  Property-Performance-and-Underwriting_FR.xlsx   Français
  Property-Performance-and-Underwriting_ES.xlsx   Español
  Property-Performance-and-Underwriting_DE.xlsx   Deutsch
  Property-Performance-and-Underwriting_IT.xlsx   Italiano
  Property-Performance-and-Underwriting_PT.xlsx   Português
  Property-Performance-and-Underwriting_TR.xlsx   Türkçe
  Property-Performance-and-Underwriting_NL.xlsx   Nederlands
  Property-Performance-and-Underwriting_RU.xlsx   Русский
  Property-Performance-and-Underwriting_FA.xlsx   فارسی
  Property-Performance-and-Underwriting_UR.xlsx   اردو
  Property-Performance-and-Underwriting_HI.xlsx   हिन्दी
  Property-Performance-and-Underwriting_ZH.xlsx   中文
  Property-Performance-and-Underwriting_ID.xlsx   Bahasa Indonesia
  Property-Performance-and-Underwriting_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
