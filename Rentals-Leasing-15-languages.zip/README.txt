Rentals & Leasing
Rent roll, tenants, leases, arrears, deposits and renewals for every owner

FILES
  Rentals-Leasing_EN.xlsx   English
  Rentals-Leasing_AR.xlsx   العربية
  Rentals-Leasing_FR.xlsx   Français
  Rentals-Leasing_ES.xlsx   Español
  Rentals-Leasing_DE.xlsx   Deutsch
  Rentals-Leasing_IT.xlsx   Italiano
  Rentals-Leasing_PT.xlsx   Português
  Rentals-Leasing_TR.xlsx   Türkçe
  Rentals-Leasing_NL.xlsx   Nederlands
  Rentals-Leasing_RU.xlsx   Русский
  Rentals-Leasing_FA.xlsx   فارسی
  Rentals-Leasing_UR.xlsx   اردو
  Rentals-Leasing_HI.xlsx   हिन्दी
  Rentals-Leasing_ZH.xlsx   中文
  Rentals-Leasing_ID.xlsx   Bahasa Indonesia
  Rentals-Leasing_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
