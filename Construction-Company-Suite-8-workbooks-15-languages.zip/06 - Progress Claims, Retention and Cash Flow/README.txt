Progress Claims, Retention and Cash Flow
Claim every month, collect retention, see the cash gap

FILES
  Progress-Claims-Retention-and-Cash-Flow_EN.xlsx   English
  Progress-Claims-Retention-and-Cash-Flow_AR.xlsx   العربية
  Progress-Claims-Retention-and-Cash-Flow_FR.xlsx   Français
  Progress-Claims-Retention-and-Cash-Flow_ES.xlsx   Español
  Progress-Claims-Retention-and-Cash-Flow_DE.xlsx   Deutsch
  Progress-Claims-Retention-and-Cash-Flow_IT.xlsx   Italiano
  Progress-Claims-Retention-and-Cash-Flow_PT.xlsx   Português
  Progress-Claims-Retention-and-Cash-Flow_TR.xlsx   Türkçe
  Progress-Claims-Retention-and-Cash-Flow_NL.xlsx   Nederlands
  Progress-Claims-Retention-and-Cash-Flow_RU.xlsx   Русский
  Progress-Claims-Retention-and-Cash-Flow_FA.xlsx   فارسی
  Progress-Claims-Retention-and-Cash-Flow_UR.xlsx   اردو
  Progress-Claims-Retention-and-Cash-Flow_HI.xlsx   हिन्दी
  Progress-Claims-Retention-and-Cash-Flow_ZH.xlsx   中文
  Progress-Claims-Retention-and-Cash-Flow_ID.xlsx   Bahasa Indonesia
  Progress-Claims-Retention-and-Cash-Flow_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
