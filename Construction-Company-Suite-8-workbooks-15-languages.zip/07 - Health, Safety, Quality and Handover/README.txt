Health, Safety, Quality and Handover
Control site safety, quality, snags and handover

FILES
  Health-Safety-Quality-and-Handover_EN.xlsx   English
  Health-Safety-Quality-and-Handover_AR.xlsx   العربية
  Health-Safety-Quality-and-Handover_FR.xlsx   Français
  Health-Safety-Quality-and-Handover_ES.xlsx   Español
  Health-Safety-Quality-and-Handover_DE.xlsx   Deutsch
  Health-Safety-Quality-and-Handover_IT.xlsx   Italiano
  Health-Safety-Quality-and-Handover_PT.xlsx   Português
  Health-Safety-Quality-and-Handover_TR.xlsx   Türkçe
  Health-Safety-Quality-and-Handover_NL.xlsx   Nederlands
  Health-Safety-Quality-and-Handover_RU.xlsx   Русский
  Health-Safety-Quality-and-Handover_FA.xlsx   فارسی
  Health-Safety-Quality-and-Handover_UR.xlsx   اردو
  Health-Safety-Quality-and-Handover_HI.xlsx   हिन्दी
  Health-Safety-Quality-and-Handover_ZH.xlsx   中文
  Health-Safety-Quality-and-Handover_ID.xlsx   Bahasa Indonesia
  Health-Safety-Quality-and-Handover_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
