Construction Company Suite
Run a construction company from eight connected Excel workbooks

WORKBOOKS
  01 - Estimating, Tenders and Contracts: Price tenders, compare quotes and control contracts
  02 - Projects and Site Diary: Project schedule, site diary and delay claims for every job you build
  03 - Job Costing and Change Orders: Budgets, forecasts and change orders that protect margin
  04 - Materials, Procurement and Equipment: Control materials, suppliers and machines
  05 - Subcontractors and Labour: Control subcontractors, payments, crews and labour cost
  06 - Progress Claims, Retention and Cash Flow: Claim every month, collect retention, see the cash gap
  07 - Health, Safety, Quality and Handover: Control site safety, quality, snags and handover
  08 - Company Finance and Performance: Profit, overheads, order book and cash in one place

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
