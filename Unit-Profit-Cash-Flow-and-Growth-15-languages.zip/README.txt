Unit Profit, Cash Flow and Growth
Know which unit makes money, how much cash you have and when to grow

FILES
  Unit-Profit-Cash-Flow-and-Growth_EN.xlsx   English
  Unit-Profit-Cash-Flow-and-Growth_AR.xlsx   العربية
  Unit-Profit-Cash-Flow-and-Growth_FR.xlsx   Français
  Unit-Profit-Cash-Flow-and-Growth_ES.xlsx   Español
  Unit-Profit-Cash-Flow-and-Growth_DE.xlsx   Deutsch
  Unit-Profit-Cash-Flow-and-Growth_IT.xlsx   Italiano
  Unit-Profit-Cash-Flow-and-Growth_PT.xlsx   Português
  Unit-Profit-Cash-Flow-and-Growth_TR.xlsx   Türkçe
  Unit-Profit-Cash-Flow-and-Growth_NL.xlsx   Nederlands
  Unit-Profit-Cash-Flow-and-Growth_RU.xlsx   Русский
  Unit-Profit-Cash-Flow-and-Growth_FA.xlsx   فارسی
  Unit-Profit-Cash-Flow-and-Growth_UR.xlsx   اردو
  Unit-Profit-Cash-Flow-and-Growth_HI.xlsx   हिन्दी
  Unit-Profit-Cash-Flow-and-Growth_ZH.xlsx   中文
  Unit-Profit-Cash-Flow-and-Growth_ID.xlsx   Bahasa Indonesia
  Unit-Profit-Cash-Flow-and-Growth_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
