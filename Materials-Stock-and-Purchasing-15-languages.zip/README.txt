Materials, Stock and Purchasing
Reorder points, lots, supplier orders and counts for candle and soap makers

FILES
  Materials-Stock-and-Purchasing_EN.xlsx   English
  Materials-Stock-and-Purchasing_AR.xlsx   العربية
  Materials-Stock-and-Purchasing_FR.xlsx   Français
  Materials-Stock-and-Purchasing_ES.xlsx   Español
  Materials-Stock-and-Purchasing_DE.xlsx   Deutsch
  Materials-Stock-and-Purchasing_IT.xlsx   Italiano
  Materials-Stock-and-Purchasing_PT.xlsx   Português
  Materials-Stock-and-Purchasing_TR.xlsx   Türkçe
  Materials-Stock-and-Purchasing_NL.xlsx   Nederlands
  Materials-Stock-and-Purchasing_RU.xlsx   Русский
  Materials-Stock-and-Purchasing_FA.xlsx   فارسی
  Materials-Stock-and-Purchasing_UR.xlsx   اردو
  Materials-Stock-and-Purchasing_HI.xlsx   हिन्दी
  Materials-Stock-and-Purchasing_ZH.xlsx   中文
  Materials-Stock-and-Purchasing_ID.xlsx   Bahasa Indonesia
  Materials-Stock-and-Purchasing_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
