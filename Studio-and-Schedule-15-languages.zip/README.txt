Studio and Schedule
Timetable, slot fill, rooms, equipment and safety log in one file

FILES
  Studio-and-Schedule_EN.xlsx   English
  Studio-and-Schedule_AR.xlsx   العربية
  Studio-and-Schedule_FR.xlsx   Français
  Studio-and-Schedule_ES.xlsx   Español
  Studio-and-Schedule_DE.xlsx   Deutsch
  Studio-and-Schedule_IT.xlsx   Italiano
  Studio-and-Schedule_PT.xlsx   Português
  Studio-and-Schedule_TR.xlsx   Türkçe
  Studio-and-Schedule_NL.xlsx   Nederlands
  Studio-and-Schedule_RU.xlsx   Русский
  Studio-and-Schedule_FA.xlsx   فارسی
  Studio-and-Schedule_UR.xlsx   اردو
  Studio-and-Schedule_HI.xlsx   हिन्दी
  Studio-and-Schedule_ZH.xlsx   中文
  Studio-and-Schedule_ID.xlsx   Bahasa Indonesia
  Studio-and-Schedule_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
