Market Radar & Valuation
Rent and sale comparables, district heat, supply, demand and valuation

FILES
  Market-Radar-Valuation_EN.xlsx   English
  Market-Radar-Valuation_AR.xlsx   العربية
  Market-Radar-Valuation_FR.xlsx   Français
  Market-Radar-Valuation_ES.xlsx   Español
  Market-Radar-Valuation_DE.xlsx   Deutsch
  Market-Radar-Valuation_IT.xlsx   Italiano
  Market-Radar-Valuation_PT.xlsx   Português
  Market-Radar-Valuation_TR.xlsx   Türkçe
  Market-Radar-Valuation_NL.xlsx   Nederlands
  Market-Radar-Valuation_RU.xlsx   Русский
  Market-Radar-Valuation_FA.xlsx   فارسی
  Market-Radar-Valuation_UR.xlsx   اردو
  Market-Radar-Valuation_HI.xlsx   हिन्दी
  Market-Radar-Valuation_ZH.xlsx   中文
  Market-Radar-Valuation_ID.xlsx   Bahasa Indonesia
  Market-Radar-Valuation_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
