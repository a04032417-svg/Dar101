Turnovers, Cleaners and Supplies
Run every clean, every cleaner and every supply shelf from one workbook

FILES
  Turnovers-Cleaners-and-Supplies_EN.xlsx   English
  Turnovers-Cleaners-and-Supplies_AR.xlsx   العربية
  Turnovers-Cleaners-and-Supplies_FR.xlsx   Français
  Turnovers-Cleaners-and-Supplies_ES.xlsx   Español
  Turnovers-Cleaners-and-Supplies_DE.xlsx   Deutsch
  Turnovers-Cleaners-and-Supplies_IT.xlsx   Italiano
  Turnovers-Cleaners-and-Supplies_PT.xlsx   Português
  Turnovers-Cleaners-and-Supplies_TR.xlsx   Türkçe
  Turnovers-Cleaners-and-Supplies_NL.xlsx   Nederlands
  Turnovers-Cleaners-and-Supplies_RU.xlsx   Русский
  Turnovers-Cleaners-and-Supplies_FA.xlsx   فارسی
  Turnovers-Cleaners-and-Supplies_UR.xlsx   اردو
  Turnovers-Cleaners-and-Supplies_HI.xlsx   हिन्दी
  Turnovers-Cleaners-and-Supplies_ZH.xlsx   中文
  Turnovers-Cleaners-and-Supplies_ID.xlsx   Bahasa Indonesia
  Turnovers-Cleaners-and-Supplies_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
