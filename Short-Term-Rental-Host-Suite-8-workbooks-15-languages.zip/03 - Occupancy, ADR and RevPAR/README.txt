Occupancy, ADR and RevPAR
See which units earn, which lag and what to do about it

FILES
  Occupancy-ADR-and-RevPAR_EN.xlsx   English
  Occupancy-ADR-and-RevPAR_AR.xlsx   العربية
  Occupancy-ADR-and-RevPAR_FR.xlsx   Français
  Occupancy-ADR-and-RevPAR_ES.xlsx   Español
  Occupancy-ADR-and-RevPAR_DE.xlsx   Deutsch
  Occupancy-ADR-and-RevPAR_IT.xlsx   Italiano
  Occupancy-ADR-and-RevPAR_PT.xlsx   Português
  Occupancy-ADR-and-RevPAR_TR.xlsx   Türkçe
  Occupancy-ADR-and-RevPAR_NL.xlsx   Nederlands
  Occupancy-ADR-and-RevPAR_RU.xlsx   Русский
  Occupancy-ADR-and-RevPAR_FA.xlsx   فارسی
  Occupancy-ADR-and-RevPAR_UR.xlsx   اردو
  Occupancy-ADR-and-RevPAR_HI.xlsx   हिन्दी
  Occupancy-ADR-and-RevPAR_ZH.xlsx   中文
  Occupancy-ADR-and-RevPAR_ID.xlsx   Bahasa Indonesia
  Occupancy-ADR-and-RevPAR_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
