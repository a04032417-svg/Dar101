Owner Statements, Fees and Local Taxes
Send every owner a clear statement and never miss a local tax date

FILES
  Owner-Statements-Fees-and-Local-Taxes_EN.xlsx   English
  Owner-Statements-Fees-and-Local-Taxes_AR.xlsx   العربية
  Owner-Statements-Fees-and-Local-Taxes_FR.xlsx   Français
  Owner-Statements-Fees-and-Local-Taxes_ES.xlsx   Español
  Owner-Statements-Fees-and-Local-Taxes_DE.xlsx   Deutsch
  Owner-Statements-Fees-and-Local-Taxes_IT.xlsx   Italiano
  Owner-Statements-Fees-and-Local-Taxes_PT.xlsx   Português
  Owner-Statements-Fees-and-Local-Taxes_TR.xlsx   Türkçe
  Owner-Statements-Fees-and-Local-Taxes_NL.xlsx   Nederlands
  Owner-Statements-Fees-and-Local-Taxes_RU.xlsx   Русский
  Owner-Statements-Fees-and-Local-Taxes_FA.xlsx   فارسی
  Owner-Statements-Fees-and-Local-Taxes_UR.xlsx   اردو
  Owner-Statements-Fees-and-Local-Taxes_HI.xlsx   हिन्दी
  Owner-Statements-Fees-and-Local-Taxes_ZH.xlsx   中文
  Owner-Statements-Fees-and-Local-Taxes_ID.xlsx   Bahasa Indonesia
  Owner-Statements-Fees-and-Local-Taxes_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
