Listings, Rates and Pricing Calendar
Price every unit and every week so no night is sold too cheap

FILES
  Listings-Rates-and-Pricing-Calendar_EN.xlsx   English
  Listings-Rates-and-Pricing-Calendar_AR.xlsx   العربية
  Listings-Rates-and-Pricing-Calendar_FR.xlsx   Français
  Listings-Rates-and-Pricing-Calendar_ES.xlsx   Español
  Listings-Rates-and-Pricing-Calendar_DE.xlsx   Deutsch
  Listings-Rates-and-Pricing-Calendar_IT.xlsx   Italiano
  Listings-Rates-and-Pricing-Calendar_PT.xlsx   Português
  Listings-Rates-and-Pricing-Calendar_TR.xlsx   Türkçe
  Listings-Rates-and-Pricing-Calendar_NL.xlsx   Nederlands
  Listings-Rates-and-Pricing-Calendar_RU.xlsx   Русский
  Listings-Rates-and-Pricing-Calendar_FA.xlsx   فارسی
  Listings-Rates-and-Pricing-Calendar_UR.xlsx   اردو
  Listings-Rates-and-Pricing-Calendar_HI.xlsx   हिन्दी
  Listings-Rates-and-Pricing-Calendar_ZH.xlsx   中文
  Listings-Rates-and-Pricing-Calendar_ID.xlsx   Bahasa Indonesia
  Listings-Rates-and-Pricing-Calendar_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
