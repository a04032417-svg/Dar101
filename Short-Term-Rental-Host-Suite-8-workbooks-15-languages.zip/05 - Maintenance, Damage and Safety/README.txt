Maintenance, Damage and Safety
Keep every unit guest-ready and know what each one costs to keep

FILES
  Maintenance-Damage-and-Safety_EN.xlsx   English
  Maintenance-Damage-and-Safety_AR.xlsx   العربية
  Maintenance-Damage-and-Safety_FR.xlsx   Français
  Maintenance-Damage-and-Safety_ES.xlsx   Español
  Maintenance-Damage-and-Safety_DE.xlsx   Deutsch
  Maintenance-Damage-and-Safety_IT.xlsx   Italiano
  Maintenance-Damage-and-Safety_PT.xlsx   Português
  Maintenance-Damage-and-Safety_TR.xlsx   Türkçe
  Maintenance-Damage-and-Safety_NL.xlsx   Nederlands
  Maintenance-Damage-and-Safety_RU.xlsx   Русский
  Maintenance-Damage-and-Safety_FA.xlsx   فارسی
  Maintenance-Damage-and-Safety_UR.xlsx   اردو
  Maintenance-Damage-and-Safety_HI.xlsx   हिन्दी
  Maintenance-Damage-and-Safety_ZH.xlsx   中文
  Maintenance-Damage-and-Safety_ID.xlsx   Bahasa Indonesia
  Maintenance-Damage-and-Safety_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
