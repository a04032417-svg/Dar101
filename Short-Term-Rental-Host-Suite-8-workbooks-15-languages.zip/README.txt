Short-Term Rental Host Suite
Know your real profit on every unit – and never sell a night too cheap

WORKBOOKS
  01 - Listings, Rates and Pricing Calendar: Price every unit and every week so no night is sold too cheap
  02 - Bookings, Channels and Payouts: Know what every booking paid, what is late and what never arrived
  03 - Occupancy, ADR and RevPAR: See which units earn, which lag and what to do about it
  04 - Turnovers, Cleaners and Supplies: Run every clean, every cleaner and every supply shelf from one workbook
  05 - Maintenance, Damage and Safety: Keep every unit guest-ready and know what each one costs to keep
  06 - Guests, Messages and Reviews: Turn every stay into a five-star review and a returning guest
  07 - Owner Statements, Fees and Local Taxes: Send every owner a clear statement and never miss a local tax date
  08 - Unit Profit, Cash Flow and Growth: Know which unit makes money, how much cash you have and when to grow

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
