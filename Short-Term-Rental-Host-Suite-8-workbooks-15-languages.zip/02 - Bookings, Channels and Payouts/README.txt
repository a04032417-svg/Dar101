Bookings, Channels and Payouts
Know what every booking paid, what is late and what never arrived

FILES
  Bookings-Channels-and-Payouts_EN.xlsx   English
  Bookings-Channels-and-Payouts_AR.xlsx   العربية
  Bookings-Channels-and-Payouts_FR.xlsx   Français
  Bookings-Channels-and-Payouts_ES.xlsx   Español
  Bookings-Channels-and-Payouts_DE.xlsx   Deutsch
  Bookings-Channels-and-Payouts_IT.xlsx   Italiano
  Bookings-Channels-and-Payouts_PT.xlsx   Português
  Bookings-Channels-and-Payouts_TR.xlsx   Türkçe
  Bookings-Channels-and-Payouts_NL.xlsx   Nederlands
  Bookings-Channels-and-Payouts_RU.xlsx   Русский
  Bookings-Channels-and-Payouts_FA.xlsx   فارسی
  Bookings-Channels-and-Payouts_UR.xlsx   اردو
  Bookings-Channels-and-Payouts_HI.xlsx   हिन्दी
  Bookings-Channels-and-Payouts_ZH.xlsx   中文
  Bookings-Channels-and-Payouts_ID.xlsx   Bahasa Indonesia
  Bookings-Channels-and-Payouts_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
