Job Costing and Change Orders
Budgets, forecasts and change orders that protect margin

FILES
  Job-Costing-and-Change-Orders_EN.xlsx   English
  Job-Costing-and-Change-Orders_AR.xlsx   العربية
  Job-Costing-and-Change-Orders_FR.xlsx   Français
  Job-Costing-and-Change-Orders_ES.xlsx   Español
  Job-Costing-and-Change-Orders_DE.xlsx   Deutsch
  Job-Costing-and-Change-Orders_IT.xlsx   Italiano
  Job-Costing-and-Change-Orders_PT.xlsx   Português
  Job-Costing-and-Change-Orders_TR.xlsx   Türkçe
  Job-Costing-and-Change-Orders_NL.xlsx   Nederlands
  Job-Costing-and-Change-Orders_RU.xlsx   Русский
  Job-Costing-and-Change-Orders_FA.xlsx   فارسی
  Job-Costing-and-Change-Orders_UR.xlsx   اردو
  Job-Costing-and-Change-Orders_HI.xlsx   हिन्दी
  Job-Costing-and-Change-Orders_ZH.xlsx   中文
  Job-Costing-and-Change-Orders_ID.xlsx   Bahasa Indonesia
  Job-Costing-and-Change-Orders_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
