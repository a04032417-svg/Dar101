Complaints, Reviews and Contracts
Complaints, reviews and office contracts for cleaning businesses

FILES
  Complaints-Reviews-and-Contracts_EN.xlsx   English
  Complaints-Reviews-and-Contracts_AR.xlsx   العربية
  Complaints-Reviews-and-Contracts_FR.xlsx   Français
  Complaints-Reviews-and-Contracts_ES.xlsx   Español
  Complaints-Reviews-and-Contracts_DE.xlsx   Deutsch
  Complaints-Reviews-and-Contracts_IT.xlsx   Italiano
  Complaints-Reviews-and-Contracts_PT.xlsx   Português
  Complaints-Reviews-and-Contracts_TR.xlsx   Türkçe
  Complaints-Reviews-and-Contracts_NL.xlsx   Nederlands
  Complaints-Reviews-and-Contracts_RU.xlsx   Русский
  Complaints-Reviews-and-Contracts_FA.xlsx   فارسی
  Complaints-Reviews-and-Contracts_UR.xlsx   اردو
  Complaints-Reviews-and-Contracts_HI.xlsx   हिन्दी
  Complaints-Reviews-and-Contracts_ZH.xlsx   中文
  Complaints-Reviews-and-Contracts_ID.xlsx   Bahasa Indonesia
  Complaints-Reviews-and-Contracts_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
