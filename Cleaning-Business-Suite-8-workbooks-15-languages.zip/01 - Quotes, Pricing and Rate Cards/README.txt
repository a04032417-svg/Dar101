Quotes, Pricing and Rate Cards
Quotes, rate card, margin and follow-ups for cleaning businesses

FILES
  Quotes-Pricing-and-Rate-Cards_EN.xlsx   English
  Quotes-Pricing-and-Rate-Cards_AR.xlsx   العربية
  Quotes-Pricing-and-Rate-Cards_FR.xlsx   Français
  Quotes-Pricing-and-Rate-Cards_ES.xlsx   Español
  Quotes-Pricing-and-Rate-Cards_DE.xlsx   Deutsch
  Quotes-Pricing-and-Rate-Cards_IT.xlsx   Italiano
  Quotes-Pricing-and-Rate-Cards_PT.xlsx   Português
  Quotes-Pricing-and-Rate-Cards_TR.xlsx   Türkçe
  Quotes-Pricing-and-Rate-Cards_NL.xlsx   Nederlands
  Quotes-Pricing-and-Rate-Cards_RU.xlsx   Русский
  Quotes-Pricing-and-Rate-Cards_FA.xlsx   فارسی
  Quotes-Pricing-and-Rate-Cards_UR.xlsx   اردو
  Quotes-Pricing-and-Rate-Cards_HI.xlsx   हिन्दी
  Quotes-Pricing-and-Rate-Cards_ZH.xlsx   中文
  Quotes-Pricing-and-Rate-Cards_ID.xlsx   Bahasa Indonesia
  Quotes-Pricing-and-Rate-Cards_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
