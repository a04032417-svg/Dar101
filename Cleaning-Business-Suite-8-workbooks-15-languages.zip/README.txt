Cleaning Business Suite
Quote right, fill every route and see the real profit on each client

WORKBOOKS
  01 - Quotes, Pricing and Rate Cards: Quotes, rate card, margin and follow-ups for cleaning businesses
  02 - Clients, Schedules and Routes: Schedules, crew days, routes and capacity for cleaning businesses
  03 - Crews, Hours, Pay and Capacity: Crew hours, pay, overtime, capacity and hiring for cleaning businesses
  04 - Job Checklists and Quality Inspections: Checklists, inspection scores, fixes and coaching for cleaning businesses
  05 - Supplies, Equipment and Cost per Job: Stock, equipment and cost per job for cleaning businesses
  06 - Invoices, Payments and Late Payers: Invoices, payments, reminders and late payers for cleaning businesses
  07 - Complaints, Reviews and Contracts: Complaints, reviews and office contracts for cleaning businesses
  08 - Job Profit, Cash Flow and Taxes: Job profit, cash flow, taxes and growth for cleaning businesses

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
