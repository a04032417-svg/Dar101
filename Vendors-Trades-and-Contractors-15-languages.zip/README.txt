Vendors, Trades and Contractors
Know which vendors and contractors deserve your next order

FILES
  Vendors-Trades-and-Contractors_EN.xlsx   English
  Vendors-Trades-and-Contractors_AR.xlsx   العربية
  Vendors-Trades-and-Contractors_FR.xlsx   Français
  Vendors-Trades-and-Contractors_ES.xlsx   Español
  Vendors-Trades-and-Contractors_DE.xlsx   Deutsch
  Vendors-Trades-and-Contractors_IT.xlsx   Italiano
  Vendors-Trades-and-Contractors_PT.xlsx   Português
  Vendors-Trades-and-Contractors_TR.xlsx   Türkçe
  Vendors-Trades-and-Contractors_NL.xlsx   Nederlands
  Vendors-Trades-and-Contractors_RU.xlsx   Русский
  Vendors-Trades-and-Contractors_FA.xlsx   فارسی
  Vendors-Trades-and-Contractors_UR.xlsx   اردو
  Vendors-Trades-and-Contractors_HI.xlsx   हिन्दी
  Vendors-Trades-and-Contractors_ZH.xlsx   中文
  Vendors-Trades-and-Contractors_ID.xlsx   Bahasa Indonesia
  Vendors-Trades-and-Contractors_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
