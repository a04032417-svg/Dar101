Property Management Suite
Run a whole property management office from six connected Excel workbooks

WORKBOOKS
  01 - Rentals & Leasing: Rent roll, tenants, leases, arrears, deposits and renewals for every owner
  02 - Maintenance & Operations: Work orders, vendors, preventive plans, assets and compliance for every building
  03 - Owner Accounting & Statements: Owner ledgers, statements, fees, payouts, reserves and budgets for every owner
  04 - Market Radar & Valuation: Rent and sale comparables, district heat, supply, demand and valuation
  05 - Short-Term & Holiday Rentals: Bookings, channels, pricing, cleaning and owner payouts for holiday homes
  06 - Management Office: Win and keep owners, run your team and see the company profit

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
