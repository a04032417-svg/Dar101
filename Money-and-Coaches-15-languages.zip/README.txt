Money and Coaches
Income, invoices, coach pay, margins and cash forecast in one file

FILES
  Money-and-Coaches_EN.xlsx   English
  Money-and-Coaches_AR.xlsx   العربية
  Money-and-Coaches_FR.xlsx   Français
  Money-and-Coaches_ES.xlsx   Español
  Money-and-Coaches_DE.xlsx   Deutsch
  Money-and-Coaches_IT.xlsx   Italiano
  Money-and-Coaches_PT.xlsx   Português
  Money-and-Coaches_TR.xlsx   Türkçe
  Money-and-Coaches_NL.xlsx   Nederlands
  Money-and-Coaches_RU.xlsx   Русский
  Money-and-Coaches_FA.xlsx   فارسی
  Money-and-Coaches_UR.xlsx   اردو
  Money-and-Coaches_HI.xlsx   हिन्दी
  Money-and-Coaches_ZH.xlsx   中文
  Money-and-Coaches_ID.xlsx   Bahasa Indonesia
  Money-and-Coaches_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
