Purchasing and Suppliers
Control purchase orders, landed cost, suppliers and payments

FILES
  Purchasing-and-Suppliers_EN.xlsx   English
  Purchasing-and-Suppliers_AR.xlsx   العربية
  Purchasing-and-Suppliers_FR.xlsx   Français
  Purchasing-and-Suppliers_ES.xlsx   Español
  Purchasing-and-Suppliers_DE.xlsx   Deutsch
  Purchasing-and-Suppliers_IT.xlsx   Italiano
  Purchasing-and-Suppliers_PT.xlsx   Português
  Purchasing-and-Suppliers_TR.xlsx   Türkçe
  Purchasing-and-Suppliers_NL.xlsx   Nederlands
  Purchasing-and-Suppliers_RU.xlsx   Русский
  Purchasing-and-Suppliers_FA.xlsx   فارسی
  Purchasing-and-Suppliers_UR.xlsx   اردو
  Purchasing-and-Suppliers_HI.xlsx   हिन्दी
  Purchasing-and-Suppliers_ZH.xlsx   中文
  Purchasing-and-Suppliers_ID.xlsx   Bahasa Indonesia
  Purchasing-and-Suppliers_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
