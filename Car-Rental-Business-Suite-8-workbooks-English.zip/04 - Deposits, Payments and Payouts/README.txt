Deposits, Payments and Payouts
Release deposits on time and chase short-paid payouts and unpaid invoices

FILES
  Deposits-Payments-and-Payouts_EN.xlsx   the workbook
  Deposits-Payments-and-Payouts_EN_DEMO-sample-data.xlsx   a copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel, Google Sheets and LibreOffice Calc. No macros.
  Google Sheets: upload the file to Google Drive and open it with Google Sheets, or use the copy link in your download.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
