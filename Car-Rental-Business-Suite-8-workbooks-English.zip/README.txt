Car Rental Business Suite
Find the car that loses money and never double-book a rental again

WORKBOOKS
  01 - Enquiries, Quotes and Rate Card: Price every quote above your own cost and see why enquiries are lost
  02 - Booking Calendar and Availability: Find a free car for any dates and catch double bookings before pickup
  03 - Handover, Return, Fees and Damage: Bill every return fee, chase every claim and match every toll to a rental
  04 - Deposits, Payments and Payouts: Release deposits on time and chase short-paid payouts and unpaid invoices
  05 - Fleet Register, Service and Renewals: Know which car is due for service, which renewal is next and what each costs
  06 - Turnaround, Runs and Staff: Get cars ready before pickup, price delivery runs and match staff to bookings
  07 - Utilisation, Profit and Pricing: See profit per vehicle, idle days and which cars to keep, reprice or sell
  08 - Finance, Replace-or-Sell and Owner Pay: Decide replace or sell, track every loan and take a safe owner draw

Each folder holds the workbook and a copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
