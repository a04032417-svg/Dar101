Supplies, Equipment and Cost per Job
Stock, equipment and cost per job for cleaning businesses

FILES
  Supplies-Equipment-and-Cost-per-Job_EN.xlsx   English
  Supplies-Equipment-and-Cost-per-Job_AR.xlsx   العربية
  Supplies-Equipment-and-Cost-per-Job_FR.xlsx   Français
  Supplies-Equipment-and-Cost-per-Job_ES.xlsx   Español
  Supplies-Equipment-and-Cost-per-Job_DE.xlsx   Deutsch
  Supplies-Equipment-and-Cost-per-Job_IT.xlsx   Italiano
  Supplies-Equipment-and-Cost-per-Job_PT.xlsx   Português
  Supplies-Equipment-and-Cost-per-Job_TR.xlsx   Türkçe
  Supplies-Equipment-and-Cost-per-Job_NL.xlsx   Nederlands
  Supplies-Equipment-and-Cost-per-Job_RU.xlsx   Русский
  Supplies-Equipment-and-Cost-per-Job_FA.xlsx   فارسی
  Supplies-Equipment-and-Cost-per-Job_UR.xlsx   اردو
  Supplies-Equipment-and-Cost-per-Job_HI.xlsx   हिन्दी
  Supplies-Equipment-and-Cost-per-Job_ZH.xlsx   中文
  Supplies-Equipment-and-Cost-per-Job_ID.xlsx   Bahasa Indonesia
  Supplies-Equipment-and-Cost-per-Job_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
