Guests, Messages and Reviews
Turn every stay into a five-star review and a returning guest

FILES
  Guests-Messages-and-Reviews_EN.xlsx   English
  Guests-Messages-and-Reviews_AR.xlsx   العربية
  Guests-Messages-and-Reviews_FR.xlsx   Français
  Guests-Messages-and-Reviews_ES.xlsx   Español
  Guests-Messages-and-Reviews_DE.xlsx   Deutsch
  Guests-Messages-and-Reviews_IT.xlsx   Italiano
  Guests-Messages-and-Reviews_PT.xlsx   Português
  Guests-Messages-and-Reviews_TR.xlsx   Türkçe
  Guests-Messages-and-Reviews_NL.xlsx   Nederlands
  Guests-Messages-and-Reviews_RU.xlsx   Русский
  Guests-Messages-and-Reviews_FA.xlsx   فارسی
  Guests-Messages-and-Reviews_UR.xlsx   اردو
  Guests-Messages-and-Reviews_HI.xlsx   हिन्दी
  Guests-Messages-and-Reviews_ZH.xlsx   中文
  Guests-Messages-and-Reviews_ID.xlsx   Bahasa Indonesia
  Guests-Messages-and-Reviews_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
