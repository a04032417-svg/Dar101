Sales, Contracts and Buyers
Sell at the best net price, track contracts and get paid on time

FILES
  Sales-Contracts-and-Buyers_EN.xlsx   English
  Sales-Contracts-and-Buyers_AR.xlsx   العربية
  Sales-Contracts-and-Buyers_FR.xlsx   Français
  Sales-Contracts-and-Buyers_ES.xlsx   Español
  Sales-Contracts-and-Buyers_DE.xlsx   Deutsch
  Sales-Contracts-and-Buyers_IT.xlsx   Italiano
  Sales-Contracts-and-Buyers_PT.xlsx   Português
  Sales-Contracts-and-Buyers_TR.xlsx   Türkçe
  Sales-Contracts-and-Buyers_NL.xlsx   Nederlands
  Sales-Contracts-and-Buyers_RU.xlsx   Русский
  Sales-Contracts-and-Buyers_FA.xlsx   فارسی
  Sales-Contracts-and-Buyers_UR.xlsx   اردو
  Sales-Contracts-and-Buyers_HI.xlsx   हिन्दी
  Sales-Contracts-and-Buyers_ZH.xlsx   中文
  Sales-Contracts-and-Buyers_ID.xlsx   Bahasa Indonesia
  Sales-Contracts-and-Buyers_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
