Production, Storage and Traceability
Milk, eggs, harvest lots, stock, cold rooms and traceability

FILES
  Production-Storage-and-Traceability_EN.xlsx   English
  Production-Storage-and-Traceability_AR.xlsx   العربية
  Production-Storage-and-Traceability_FR.xlsx   Français
  Production-Storage-and-Traceability_ES.xlsx   Español
  Production-Storage-and-Traceability_DE.xlsx   Deutsch
  Production-Storage-and-Traceability_IT.xlsx   Italiano
  Production-Storage-and-Traceability_PT.xlsx   Português
  Production-Storage-and-Traceability_TR.xlsx   Türkçe
  Production-Storage-and-Traceability_NL.xlsx   Nederlands
  Production-Storage-and-Traceability_RU.xlsx   Русский
  Production-Storage-and-Traceability_FA.xlsx   فارسی
  Production-Storage-and-Traceability_UR.xlsx   اردو
  Production-Storage-and-Traceability_HI.xlsx   हिन्दी
  Production-Storage-and-Traceability_ZH.xlsx   中文
  Production-Storage-and-Traceability_ID.xlsx   Bahasa Indonesia
  Production-Storage-and-Traceability_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
