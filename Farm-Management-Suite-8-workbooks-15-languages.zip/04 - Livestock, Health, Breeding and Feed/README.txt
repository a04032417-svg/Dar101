Livestock, Health, Breeding and Feed
Run herds, health, breeding, feed and grazing from one file

FILES
  Livestock-Health-Breeding-and-Feed_EN.xlsx   English
  Livestock-Health-Breeding-and-Feed_AR.xlsx   العربية
  Livestock-Health-Breeding-and-Feed_FR.xlsx   Français
  Livestock-Health-Breeding-and-Feed_ES.xlsx   Español
  Livestock-Health-Breeding-and-Feed_DE.xlsx   Deutsch
  Livestock-Health-Breeding-and-Feed_IT.xlsx   Italiano
  Livestock-Health-Breeding-and-Feed_PT.xlsx   Português
  Livestock-Health-Breeding-and-Feed_TR.xlsx   Türkçe
  Livestock-Health-Breeding-and-Feed_NL.xlsx   Nederlands
  Livestock-Health-Breeding-and-Feed_RU.xlsx   Русский
  Livestock-Health-Breeding-and-Feed_FA.xlsx   فارسی
  Livestock-Health-Breeding-and-Feed_UR.xlsx   اردو
  Livestock-Health-Breeding-and-Feed_HI.xlsx   हिन्दी
  Livestock-Health-Breeding-and-Feed_ZH.xlsx   中文
  Livestock-Health-Breeding-and-Feed_ID.xlsx   Bahasa Indonesia
  Livestock-Health-Breeding-and-Feed_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
