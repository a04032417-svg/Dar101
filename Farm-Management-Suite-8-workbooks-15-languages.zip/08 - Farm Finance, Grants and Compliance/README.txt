Farm Finance, Grants and Compliance
Profit per field, budget, cash, loans, grants, insurance and records

FILES
  Farm-Finance-Grants-and-Compliance_EN.xlsx   English
  Farm-Finance-Grants-and-Compliance_AR.xlsx   العربية
  Farm-Finance-Grants-and-Compliance_FR.xlsx   Français
  Farm-Finance-Grants-and-Compliance_ES.xlsx   Español
  Farm-Finance-Grants-and-Compliance_DE.xlsx   Deutsch
  Farm-Finance-Grants-and-Compliance_IT.xlsx   Italiano
  Farm-Finance-Grants-and-Compliance_PT.xlsx   Português
  Farm-Finance-Grants-and-Compliance_TR.xlsx   Türkçe
  Farm-Finance-Grants-and-Compliance_NL.xlsx   Nederlands
  Farm-Finance-Grants-and-Compliance_RU.xlsx   Русский
  Farm-Finance-Grants-and-Compliance_FA.xlsx   فارسی
  Farm-Finance-Grants-and-Compliance_UR.xlsx   اردو
  Farm-Finance-Grants-and-Compliance_HI.xlsx   हिन्दी
  Farm-Finance-Grants-and-Compliance_ZH.xlsx   中文
  Farm-Finance-Grants-and-Compliance_ID.xlsx   Bahasa Indonesia
  Farm-Finance-Grants-and-Compliance_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
