Farm Management Suite
Run a whole farm from eight connected Excel workbooks

WORKBOOKS
  01 - Crop Planning, Fields and Seasons: Plan fields, crops, rotation, seed and margin for the season
  02 - Field Operations, Spraying and Harvest: Daily field work, spray records, intervals, loads and yield per field
  03 - Inputs, Fertiliser and Irrigation: Control inputs, fertiliser, chemicals, water and pump cost
  04 - Livestock, Health, Breeding and Feed: Run herds, health, breeding, feed and grazing from one file
  05 - Production, Storage and Traceability: Milk, eggs, harvest lots, stock, cold rooms and traceability
  06 - Machinery, Fuel and Labour: Machines, fuel, seasonal workers, pay and safety in one file
  07 - Sales, Contracts and Buyers: Sell at the best net price, track contracts and get paid on time
  08 - Farm Finance, Grants and Compliance: Profit per field, budget, cash, loans, grants, insurance and records

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
