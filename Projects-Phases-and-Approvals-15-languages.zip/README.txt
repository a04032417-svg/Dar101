Projects, Phases and Approvals
Phases, approvals, hours and margin for every design project

FILES
  Projects-Phases-and-Approvals_EN.xlsx   English
  Projects-Phases-and-Approvals_AR.xlsx   العربية
  Projects-Phases-and-Approvals_FR.xlsx   Français
  Projects-Phases-and-Approvals_ES.xlsx   Español
  Projects-Phases-and-Approvals_DE.xlsx   Deutsch
  Projects-Phases-and-Approvals_IT.xlsx   Italiano
  Projects-Phases-and-Approvals_PT.xlsx   Português
  Projects-Phases-and-Approvals_TR.xlsx   Türkçe
  Projects-Phases-and-Approvals_NL.xlsx   Nederlands
  Projects-Phases-and-Approvals_RU.xlsx   Русский
  Projects-Phases-and-Approvals_FA.xlsx   فارسی
  Projects-Phases-and-Approvals_UR.xlsx   اردو
  Projects-Phases-and-Approvals_HI.xlsx   हिन्दी
  Projects-Phases-and-Approvals_ZH.xlsx   中文
  Projects-Phases-and-Approvals_ID.xlsx   Bahasa Indonesia
  Projects-Phases-and-Approvals_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
