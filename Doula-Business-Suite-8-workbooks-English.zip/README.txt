Doula Business Suite
Know which package earns least per hour and who covers the next due date

WORKBOOKS
  01 - Enquiries, Consultations, Quotes: Price each quote by income per hour and see where enquiries drop out
  02 - Packages, Pricing and Profit: Rank every package by income per hour and test a price before you change it
  03 - Contracts, Deposits and Payment Plans: Chase the right balance first and see cash held for work not yet done
  04 - On-Call Capacity and Backup Cover: Test any new due date against windows, monthly cap and backup cover
  05 - Visits, Hours, Mileage and Births: Compare planned and real hours, miles and rest days for every client
  06 - Doulas, Agency Splits and Pay Runs: Check each pay run and find the split that costs the agency money
  07 - Referrals, Classes, Reviews, Marketing: Rank sources by income, find class break-even and chase reviews and thank-yous
  08 - Money, Owner Pay and Renewals: 12-month cash forecast, owner draw check and renewal dates in red and amber

Each folder holds the workbook and a copy full of sample data.
Standard .xlsx files for Microsoft Excel, Google Sheets and LibreOffice Calc. No macros.
Google Sheets: open Google-Sheets-copy-links.txt and press "Make a copy" on each link.
Personal use licence for one business.
