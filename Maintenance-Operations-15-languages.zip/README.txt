Maintenance & Operations
Work orders, vendors, preventive plans, assets and compliance for every building

FILES
  Maintenance-Operations_EN.xlsx   English
  Maintenance-Operations_AR.xlsx   العربية
  Maintenance-Operations_FR.xlsx   Français
  Maintenance-Operations_ES.xlsx   Español
  Maintenance-Operations_DE.xlsx   Deutsch
  Maintenance-Operations_IT.xlsx   Italiano
  Maintenance-Operations_PT.xlsx   Português
  Maintenance-Operations_TR.xlsx   Türkçe
  Maintenance-Operations_NL.xlsx   Nederlands
  Maintenance-Operations_RU.xlsx   Русский
  Maintenance-Operations_FA.xlsx   فارسی
  Maintenance-Operations_UR.xlsx   اردو
  Maintenance-Operations_HI.xlsx   हिन्दी
  Maintenance-Operations_ZH.xlsx   中文
  Maintenance-Operations_ID.xlsx   Bahasa Indonesia
  Maintenance-Operations_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
