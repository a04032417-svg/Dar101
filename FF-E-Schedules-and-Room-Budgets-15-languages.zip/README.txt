FF&E Schedules and Room Budgets
Specify every item and keep every room on budget

FILES
  FF-E-Schedules-and-Room-Budgets_EN.xlsx   English
  FF-E-Schedules-and-Room-Budgets_AR.xlsx   العربية
  FF-E-Schedules-and-Room-Budgets_FR.xlsx   Français
  FF-E-Schedules-and-Room-Budgets_ES.xlsx   Español
  FF-E-Schedules-and-Room-Budgets_DE.xlsx   Deutsch
  FF-E-Schedules-and-Room-Budgets_IT.xlsx   Italiano
  FF-E-Schedules-and-Room-Budgets_PT.xlsx   Português
  FF-E-Schedules-and-Room-Budgets_TR.xlsx   Türkçe
  FF-E-Schedules-and-Room-Budgets_NL.xlsx   Nederlands
  FF-E-Schedules-and-Room-Budgets_RU.xlsx   Русский
  FF-E-Schedules-and-Room-Budgets_FA.xlsx   فارسی
  FF-E-Schedules-and-Room-Budgets_UR.xlsx   اردو
  FF-E-Schedules-and-Room-Budgets_HI.xlsx   हिन्दी
  FF-E-Schedules-and-Room-Budgets_ZH.xlsx   中文
  FF-E-Schedules-and-Room-Budgets_ID.xlsx   Bahasa Indonesia
  FF-E-Schedules-and-Room-Budgets_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
