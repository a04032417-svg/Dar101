Clients, Contracts and Onboarding
Clients, contracts and onboarding for your social media business

FILES
  Clients-Contracts-and-Onboarding_EN.xlsx   English
  Clients-Contracts-and-Onboarding_AR.xlsx   العربية
  Clients-Contracts-and-Onboarding_FR.xlsx   Français
  Clients-Contracts-and-Onboarding_ES.xlsx   Español
  Clients-Contracts-and-Onboarding_DE.xlsx   Deutsch
  Clients-Contracts-and-Onboarding_IT.xlsx   Italiano
  Clients-Contracts-and-Onboarding_PT.xlsx   Português
  Clients-Contracts-and-Onboarding_TR.xlsx   Türkçe
  Clients-Contracts-and-Onboarding_NL.xlsx   Nederlands
  Clients-Contracts-and-Onboarding_RU.xlsx   Русский
  Clients-Contracts-and-Onboarding_FA.xlsx   فارسی
  Clients-Contracts-and-Onboarding_UR.xlsx   اردو
  Clients-Contracts-and-Onboarding_HI.xlsx   हिन्दी
  Clients-Contracts-and-Onboarding_ZH.xlsx   中文
  Clients-Contracts-and-Onboarding_ID.xlsx   Bahasa Indonesia
  Clients-Contracts-and-Onboarding_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
