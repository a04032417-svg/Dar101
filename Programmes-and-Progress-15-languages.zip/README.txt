Programmes and Progress
Exercise library, programmes, workout log, records and goals in one file

FILES
  Programmes-and-Progress_EN.xlsx   English
  Programmes-and-Progress_AR.xlsx   العربية
  Programmes-and-Progress_FR.xlsx   Français
  Programmes-and-Progress_ES.xlsx   Español
  Programmes-and-Progress_DE.xlsx   Deutsch
  Programmes-and-Progress_IT.xlsx   Italiano
  Programmes-and-Progress_PT.xlsx   Português
  Programmes-and-Progress_TR.xlsx   Türkçe
  Programmes-and-Progress_NL.xlsx   Nederlands
  Programmes-and-Progress_RU.xlsx   Русский
  Programmes-and-Progress_FA.xlsx   فارسی
  Programmes-and-Progress_UR.xlsx   اردو
  Programmes-and-Progress_HI.xlsx   हिन्दी
  Programmes-and-Progress_ZH.xlsx   中文
  Programmes-and-Progress_ID.xlsx   Bahasa Indonesia
  Programmes-and-Progress_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
