Tax and Compliance
Tax deadlines, returns, notices and penalties for every client in one file

FILES
  Tax-and-Compliance_EN.xlsx   English
  Tax-and-Compliance_AR.xlsx   العربية
  Tax-and-Compliance_FR.xlsx   Français
  Tax-and-Compliance_ES.xlsx   Español
  Tax-and-Compliance_DE.xlsx   Deutsch
  Tax-and-Compliance_IT.xlsx   Italiano
  Tax-and-Compliance_PT.xlsx   Português
  Tax-and-Compliance_TR.xlsx   Türkçe
  Tax-and-Compliance_NL.xlsx   Nederlands
  Tax-and-Compliance_RU.xlsx   Русский
  Tax-and-Compliance_FA.xlsx   فارسی
  Tax-and-Compliance_UR.xlsx   اردو
  Tax-and-Compliance_HI.xlsx   हिन्दी
  Tax-and-Compliance_ZH.xlsx   中文
  Tax-and-Compliance_ID.xlsx   Bahasa Indonesia
  Tax-and-Compliance_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
