Products, Costs and Pricing
Know the real margin of every product on every channel

FILES
  Products-Costs-and-Pricing_EN.xlsx   English
  Products-Costs-and-Pricing_AR.xlsx   العربية
  Products-Costs-and-Pricing_FR.xlsx   Français
  Products-Costs-and-Pricing_ES.xlsx   Español
  Products-Costs-and-Pricing_DE.xlsx   Deutsch
  Products-Costs-and-Pricing_IT.xlsx   Italiano
  Products-Costs-and-Pricing_PT.xlsx   Português
  Products-Costs-and-Pricing_TR.xlsx   Türkçe
  Products-Costs-and-Pricing_NL.xlsx   Nederlands
  Products-Costs-and-Pricing_RU.xlsx   Русский
  Products-Costs-and-Pricing_FA.xlsx   فارسی
  Products-Costs-and-Pricing_UR.xlsx   اردو
  Products-Costs-and-Pricing_HI.xlsx   हिन्दी
  Products-Costs-and-Pricing_ZH.xlsx   中文
  Products-Costs-and-Pricing_ID.xlsx   Bahasa Indonesia
  Products-Costs-and-Pricing_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
