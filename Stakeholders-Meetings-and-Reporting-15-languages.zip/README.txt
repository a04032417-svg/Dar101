Stakeholders, Meetings and Reporting
Keep sponsors informed, meetings short and every report on time

FILES
  Stakeholders-Meetings-and-Reporting_EN.xlsx   English
  Stakeholders-Meetings-and-Reporting_AR.xlsx   العربية
  Stakeholders-Meetings-and-Reporting_FR.xlsx   Français
  Stakeholders-Meetings-and-Reporting_ES.xlsx   Español
  Stakeholders-Meetings-and-Reporting_DE.xlsx   Deutsch
  Stakeholders-Meetings-and-Reporting_IT.xlsx   Italiano
  Stakeholders-Meetings-and-Reporting_PT.xlsx   Português
  Stakeholders-Meetings-and-Reporting_TR.xlsx   Türkçe
  Stakeholders-Meetings-and-Reporting_NL.xlsx   Nederlands
  Stakeholders-Meetings-and-Reporting_RU.xlsx   Русский
  Stakeholders-Meetings-and-Reporting_FA.xlsx   فارسی
  Stakeholders-Meetings-and-Reporting_UR.xlsx   اردو
  Stakeholders-Meetings-and-Reporting_HI.xlsx   हिन्दी
  Stakeholders-Meetings-and-Reporting_ZH.xlsx   中文
  Stakeholders-Meetings-and-Reporting_ID.xlsx   Bahasa Indonesia
  Stakeholders-Meetings-and-Reporting_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
