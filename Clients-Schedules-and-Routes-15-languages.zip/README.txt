Clients, Schedules and Routes
Schedules, crew days, routes and capacity for cleaning businesses

FILES
  Clients-Schedules-and-Routes_EN.xlsx   English
  Clients-Schedules-and-Routes_AR.xlsx   العربية
  Clients-Schedules-and-Routes_FR.xlsx   Français
  Clients-Schedules-and-Routes_ES.xlsx   Español
  Clients-Schedules-and-Routes_DE.xlsx   Deutsch
  Clients-Schedules-and-Routes_IT.xlsx   Italiano
  Clients-Schedules-and-Routes_PT.xlsx   Português
  Clients-Schedules-and-Routes_TR.xlsx   Türkçe
  Clients-Schedules-and-Routes_NL.xlsx   Nederlands
  Clients-Schedules-and-Routes_RU.xlsx   Русский
  Clients-Schedules-and-Routes_FA.xlsx   فارسی
  Clients-Schedules-and-Routes_UR.xlsx   اردو
  Clients-Schedules-and-Routes_HI.xlsx   हिन्दी
  Clients-Schedules-and-Routes_ZH.xlsx   中文
  Clients-Schedules-and-Routes_ID.xlsx   Bahasa Indonesia
  Clients-Schedules-and-Routes_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
