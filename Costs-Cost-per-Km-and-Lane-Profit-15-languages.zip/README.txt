Costs, Cost per Km and Lane Profit
Know what a km costs and which lanes lose money

FILES
  Costs-Cost-per-Km-and-Lane-Profit_EN.xlsx   English
  Costs-Cost-per-Km-and-Lane-Profit_AR.xlsx   العربية
  Costs-Cost-per-Km-and-Lane-Profit_FR.xlsx   Français
  Costs-Cost-per-Km-and-Lane-Profit_ES.xlsx   Español
  Costs-Cost-per-Km-and-Lane-Profit_DE.xlsx   Deutsch
  Costs-Cost-per-Km-and-Lane-Profit_IT.xlsx   Italiano
  Costs-Cost-per-Km-and-Lane-Profit_PT.xlsx   Português
  Costs-Cost-per-Km-and-Lane-Profit_TR.xlsx   Türkçe
  Costs-Cost-per-Km-and-Lane-Profit_NL.xlsx   Nederlands
  Costs-Cost-per-Km-and-Lane-Profit_RU.xlsx   Русский
  Costs-Cost-per-Km-and-Lane-Profit_FA.xlsx   فارسی
  Costs-Cost-per-Km-and-Lane-Profit_UR.xlsx   اردو
  Costs-Cost-per-Km-and-Lane-Profit_HI.xlsx   हिन्दी
  Costs-Cost-per-Km-and-Lane-Profit_ZH.xlsx   中文
  Costs-Cost-per-Km-and-Lane-Profit_ID.xlsx   Bahasa Indonesia
  Costs-Cost-per-Km-and-Lane-Profit_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
