Time, Billing, Retainers and Invoices
Get paid for your time and your product, on time

FILES
  Time-Billing-Retainers-and-Invoices_EN.xlsx   English
  Time-Billing-Retainers-and-Invoices_AR.xlsx   العربية
  Time-Billing-Retainers-and-Invoices_FR.xlsx   Français
  Time-Billing-Retainers-and-Invoices_ES.xlsx   Español
  Time-Billing-Retainers-and-Invoices_DE.xlsx   Deutsch
  Time-Billing-Retainers-and-Invoices_IT.xlsx   Italiano
  Time-Billing-Retainers-and-Invoices_PT.xlsx   Português
  Time-Billing-Retainers-and-Invoices_TR.xlsx   Türkçe
  Time-Billing-Retainers-and-Invoices_NL.xlsx   Nederlands
  Time-Billing-Retainers-and-Invoices_RU.xlsx   Русский
  Time-Billing-Retainers-and-Invoices_FA.xlsx   فارسی
  Time-Billing-Retainers-and-Invoices_UR.xlsx   اردو
  Time-Billing-Retainers-and-Invoices_HI.xlsx   हिन्दी
  Time-Billing-Retainers-and-Invoices_ZH.xlsx   中文
  Time-Billing-Retainers-and-Invoices_ID.xlsx   Bahasa Indonesia
  Time-Billing-Retainers-and-Invoices_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
