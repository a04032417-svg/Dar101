Machinery, Fuel and Labour
Machines, fuel, seasonal workers, pay and safety in one file

FILES
  Machinery-Fuel-and-Labour_EN.xlsx   English
  Machinery-Fuel-and-Labour_AR.xlsx   العربية
  Machinery-Fuel-and-Labour_FR.xlsx   Français
  Machinery-Fuel-and-Labour_ES.xlsx   Español
  Machinery-Fuel-and-Labour_DE.xlsx   Deutsch
  Machinery-Fuel-and-Labour_IT.xlsx   Italiano
  Machinery-Fuel-and-Labour_PT.xlsx   Português
  Machinery-Fuel-and-Labour_TR.xlsx   Türkçe
  Machinery-Fuel-and-Labour_NL.xlsx   Nederlands
  Machinery-Fuel-and-Labour_RU.xlsx   Русский
  Machinery-Fuel-and-Labour_FA.xlsx   فارسی
  Machinery-Fuel-and-Labour_UR.xlsx   اردو
  Machinery-Fuel-and-Labour_HI.xlsx   हिन्दी
  Machinery-Fuel-and-Labour_ZH.xlsx   中文
  Machinery-Fuel-and-Labour_ID.xlsx   Bahasa Indonesia
  Machinery-Fuel-and-Labour_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
