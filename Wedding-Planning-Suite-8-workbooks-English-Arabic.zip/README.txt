Wedding Planning Suite
Know what you owe, who is coming and where everyone sits

WORKBOOKS
  01 - Budget, Payments and Cash Plan: Know you are funded, what is due next and when cash runs short
  02 - Guests, Invitations and RSVPs: Know how many guests will come and which households to chase
  03 - Vendors, Quotes and Contracts: Know the true cost of every quote and your next contract date
  04 - Master Timeline and Task Owners: See what is late, who holds too much and what to do this week
  05 - Venue Capacity and Seating Plan: Know your guests fit, seat every table and order the right rentals
  06 - Wedding Party and Day-Of Run-of-Show: Fit the day to your venue hours and give everyone a page of their own
  07 - Events, Travel and Honeymoon: See what each event, the travel and the honeymoon cost, and the gap
  08 - Attire, Decor, Gifts and Wrap-up: Make or buy, clear the thank-you backlog and see the cost per guest

Each folder holds the workbook in English and in Arabic, and a copy of each full of sample data. / كل مجلد فيه ملف العمل بالإنجليزية وبالعربية، ونسخة من كل منهما مملوءة ببيانات تجريبية.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
