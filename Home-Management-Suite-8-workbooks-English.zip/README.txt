Home Management Suite
Know what to cook, who does what and what is due, all in 8 workbooks

WORKBOOKS
  01 - Meal Plan and Grocery List: Week of dinners in, grocery list out: minus stock, rounded to your pack sizes
  02 - Pantry, Freezer and Leftovers: Use-by dates ranked, so you know what to eat first and what to cook tonight
  03 - Chores, Laundry and Rotation: Overdue chores ranked and each adult's share shown against the share agreed
  04 - Home Maintenance and Repairs: A next due date for every task, the most overdue first, and repeat repairs found
  05 - Home Inventory and Warranties: Days of warranty left for every item, with its receipt and manual place
  06 - Family Calendar, Pets and Vehicles: Overlapping events, double-booked drivers and due vehicle dates in one place
  07 - Documents, Contacts and Renewals: Every expiry and renewal ranked for the next 90 days, with the date to start
  08 - Projects, Hosting and Declutter: Dates, owners and costs for a move, a renovation, a dinner and a declutter

Each folder holds the workbook and a copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
