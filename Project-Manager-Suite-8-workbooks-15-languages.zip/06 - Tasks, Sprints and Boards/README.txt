Tasks, Sprints and Boards
Plan sprints, run the board and forecast the release

FILES
  Tasks-Sprints-and-Boards_EN.xlsx   English
  Tasks-Sprints-and-Boards_AR.xlsx   العربية
  Tasks-Sprints-and-Boards_FR.xlsx   Français
  Tasks-Sprints-and-Boards_ES.xlsx   Español
  Tasks-Sprints-and-Boards_DE.xlsx   Deutsch
  Tasks-Sprints-and-Boards_IT.xlsx   Italiano
  Tasks-Sprints-and-Boards_PT.xlsx   Português
  Tasks-Sprints-and-Boards_TR.xlsx   Türkçe
  Tasks-Sprints-and-Boards_NL.xlsx   Nederlands
  Tasks-Sprints-and-Boards_RU.xlsx   Русский
  Tasks-Sprints-and-Boards_FA.xlsx   فارسی
  Tasks-Sprints-and-Boards_UR.xlsx   اردو
  Tasks-Sprints-and-Boards_HI.xlsx   हिन्दी
  Tasks-Sprints-and-Boards_ZH.xlsx   中文
  Tasks-Sprints-and-Boards_ID.xlsx   Bahasa Indonesia
  Tasks-Sprints-and-Boards_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
