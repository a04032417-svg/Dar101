Project Manager Suite
Deliver every project on time and on budget – see problems weeks earlier

WORKBOOKS
  01 - Portfolio and Project Initiation: Score proposals, sign charters and pass the gates before every start
  02 - Planning and Scheduling: Plan tasks, dates, baselines and delays for every project
  03 - Team, Capacity and Time: Plan who is free, who is overloaded and where the hours go
  04 - Budget, Costs and Procurement: Control project budget, forecast, purchasing and client billing
  05 - Risks, Issues, Changes and Decisions: Control project risks, issues, changes, decisions and assumptions
  06 - Tasks, Sprints and Boards: Plan sprints, run the board and forecast the release
  07 - Stakeholders, Meetings and Reporting: Keep sponsors informed, meetings short and every report on time
  08 - Quality, Delivery and Closure: Acceptance, tests, defects, payments, handover and project closure

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
