Planning and Scheduling
Plan tasks, dates, baselines and delays for every project

FILES
  Planning-and-Scheduling_EN.xlsx   English
  Planning-and-Scheduling_AR.xlsx   العربية
  Planning-and-Scheduling_FR.xlsx   Français
  Planning-and-Scheduling_ES.xlsx   Español
  Planning-and-Scheduling_DE.xlsx   Deutsch
  Planning-and-Scheduling_IT.xlsx   Italiano
  Planning-and-Scheduling_PT.xlsx   Português
  Planning-and-Scheduling_TR.xlsx   Türkçe
  Planning-and-Scheduling_NL.xlsx   Nederlands
  Planning-and-Scheduling_RU.xlsx   Русский
  Planning-and-Scheduling_FA.xlsx   فارسی
  Planning-and-Scheduling_UR.xlsx   اردو
  Planning-and-Scheduling_HI.xlsx   हिन्दी
  Planning-and-Scheduling_ZH.xlsx   中文
  Planning-and-Scheduling_ID.xlsx   Bahasa Indonesia
  Planning-and-Scheduling_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
