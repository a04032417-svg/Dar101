Team, Capacity and Time
Plan who is free, who is overloaded and where the hours go

FILES
  Team-Capacity-and-Time_EN.xlsx   English
  Team-Capacity-and-Time_AR.xlsx   العربية
  Team-Capacity-and-Time_FR.xlsx   Français
  Team-Capacity-and-Time_ES.xlsx   Español
  Team-Capacity-and-Time_DE.xlsx   Deutsch
  Team-Capacity-and-Time_IT.xlsx   Italiano
  Team-Capacity-and-Time_PT.xlsx   Português
  Team-Capacity-and-Time_TR.xlsx   Türkçe
  Team-Capacity-and-Time_NL.xlsx   Nederlands
  Team-Capacity-and-Time_RU.xlsx   Русский
  Team-Capacity-and-Time_FA.xlsx   فارسی
  Team-Capacity-and-Time_UR.xlsx   اردو
  Team-Capacity-and-Time_HI.xlsx   हिन्दी
  Team-Capacity-and-Time_ZH.xlsx   中文
  Team-Capacity-and-Time_ID.xlsx   Bahasa Indonesia
  Team-Capacity-and-Time_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
