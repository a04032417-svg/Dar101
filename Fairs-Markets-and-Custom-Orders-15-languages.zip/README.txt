Fairs, Markets and Custom Orders
Fair profit, stock lists, custom quotes and deposits for candle and soap makers

FILES
  Fairs-Markets-and-Custom-Orders_EN.xlsx   English
  Fairs-Markets-and-Custom-Orders_AR.xlsx   العربية
  Fairs-Markets-and-Custom-Orders_FR.xlsx   Français
  Fairs-Markets-and-Custom-Orders_ES.xlsx   Español
  Fairs-Markets-and-Custom-Orders_DE.xlsx   Deutsch
  Fairs-Markets-and-Custom-Orders_IT.xlsx   Italiano
  Fairs-Markets-and-Custom-Orders_PT.xlsx   Português
  Fairs-Markets-and-Custom-Orders_TR.xlsx   Türkçe
  Fairs-Markets-and-Custom-Orders_NL.xlsx   Nederlands
  Fairs-Markets-and-Custom-Orders_RU.xlsx   Русский
  Fairs-Markets-and-Custom-Orders_FA.xlsx   فارسی
  Fairs-Markets-and-Custom-Orders_UR.xlsx   اردو
  Fairs-Markets-and-Custom-Orders_HI.xlsx   हिन्दी
  Fairs-Markets-and-Custom-Orders_ZH.xlsx   中文
  Fairs-Markets-and-Custom-Orders_ID.xlsx   Bahasa Indonesia
  Fairs-Markets-and-Custom-Orders_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
