Job Checklists and Quality Inspections
Checklists, inspection scores, fixes and coaching for cleaning businesses

FILES
  Job-Checklists-and-Quality-Inspections_EN.xlsx   English
  Job-Checklists-and-Quality-Inspections_AR.xlsx   العربية
  Job-Checklists-and-Quality-Inspections_FR.xlsx   Français
  Job-Checklists-and-Quality-Inspections_ES.xlsx   Español
  Job-Checklists-and-Quality-Inspections_DE.xlsx   Deutsch
  Job-Checklists-and-Quality-Inspections_IT.xlsx   Italiano
  Job-Checklists-and-Quality-Inspections_PT.xlsx   Português
  Job-Checklists-and-Quality-Inspections_TR.xlsx   Türkçe
  Job-Checklists-and-Quality-Inspections_NL.xlsx   Nederlands
  Job-Checklists-and-Quality-Inspections_RU.xlsx   Русский
  Job-Checklists-and-Quality-Inspections_FA.xlsx   فارسی
  Job-Checklists-and-Quality-Inspections_UR.xlsx   اردو
  Job-Checklists-and-Quality-Inspections_HI.xlsx   हिन्दी
  Job-Checklists-and-Quality-Inspections_ZH.xlsx   中文
  Job-Checklists-and-Quality-Inspections_ID.xlsx   Bahasa Indonesia
  Job-Checklists-and-Quality-Inspections_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
