Portfolio and Project Initiation
Score proposals, sign charters and pass the gates before every start

FILES
  Portfolio-and-Project-Initiation_EN.xlsx   English
  Portfolio-and-Project-Initiation_AR.xlsx   العربية
  Portfolio-and-Project-Initiation_FR.xlsx   Français
  Portfolio-and-Project-Initiation_ES.xlsx   Español
  Portfolio-and-Project-Initiation_DE.xlsx   Deutsch
  Portfolio-and-Project-Initiation_IT.xlsx   Italiano
  Portfolio-and-Project-Initiation_PT.xlsx   Português
  Portfolio-and-Project-Initiation_TR.xlsx   Türkçe
  Portfolio-and-Project-Initiation_NL.xlsx   Nederlands
  Portfolio-and-Project-Initiation_RU.xlsx   Русский
  Portfolio-and-Project-Initiation_FA.xlsx   فارسی
  Portfolio-and-Project-Initiation_UR.xlsx   اردو
  Portfolio-and-Project-Initiation_HI.xlsx   हिन्दी
  Portfolio-and-Project-Initiation_ZH.xlsx   中文
  Portfolio-and-Project-Initiation_ID.xlsx   Bahasa Indonesia
  Portfolio-and-Project-Initiation_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
