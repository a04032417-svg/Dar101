Crews, Hours, Pay and Capacity
Crew hours, pay, overtime, capacity and hiring for cleaning businesses

FILES
  Crews-Hours-Pay-and-Capacity_EN.xlsx   English
  Crews-Hours-Pay-and-Capacity_AR.xlsx   العربية
  Crews-Hours-Pay-and-Capacity_FR.xlsx   Français
  Crews-Hours-Pay-and-Capacity_ES.xlsx   Español
  Crews-Hours-Pay-and-Capacity_DE.xlsx   Deutsch
  Crews-Hours-Pay-and-Capacity_IT.xlsx   Italiano
  Crews-Hours-Pay-and-Capacity_PT.xlsx   Português
  Crews-Hours-Pay-and-Capacity_TR.xlsx   Türkçe
  Crews-Hours-Pay-and-Capacity_NL.xlsx   Nederlands
  Crews-Hours-Pay-and-Capacity_RU.xlsx   Русский
  Crews-Hours-Pay-and-Capacity_FA.xlsx   فارسی
  Crews-Hours-Pay-and-Capacity_UR.xlsx   اردو
  Crews-Hours-Pay-and-Capacity_HI.xlsx   हिन्दी
  Crews-Hours-Pay-and-Capacity_ZH.xlsx   中文
  Crews-Hours-Pay-and-Capacity_ID.xlsx   Bahasa Indonesia
  Crews-Hours-Pay-and-Capacity_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
