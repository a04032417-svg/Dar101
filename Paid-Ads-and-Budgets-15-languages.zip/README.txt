Paid Ads and Budgets
Ad spend, budgets and results for every client you run ads for

FILES
  Paid-Ads-and-Budgets_EN.xlsx   English
  Paid-Ads-and-Budgets_AR.xlsx   العربية
  Paid-Ads-and-Budgets_FR.xlsx   Français
  Paid-Ads-and-Budgets_ES.xlsx   Español
  Paid-Ads-and-Budgets_DE.xlsx   Deutsch
  Paid-Ads-and-Budgets_IT.xlsx   Italiano
  Paid-Ads-and-Budgets_PT.xlsx   Português
  Paid-Ads-and-Budgets_TR.xlsx   Türkçe
  Paid-Ads-and-Budgets_NL.xlsx   Nederlands
  Paid-Ads-and-Budgets_RU.xlsx   Русский
  Paid-Ads-and-Budgets_FA.xlsx   فارسی
  Paid-Ads-and-Budgets_UR.xlsx   اردو
  Paid-Ads-and-Budgets_HI.xlsx   हिन्दी
  Paid-Ads-and-Budgets_ZH.xlsx   中文
  Paid-Ads-and-Budgets_ID.xlsx   Bahasa Indonesia
  Paid-Ads-and-Budgets_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
