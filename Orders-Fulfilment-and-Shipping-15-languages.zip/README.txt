Orders, Fulfilment and Shipping
Pick, pack and ship every order on time and see what shipping costs

FILES
  Orders-Fulfilment-and-Shipping_EN.xlsx   English
  Orders-Fulfilment-and-Shipping_AR.xlsx   العربية
  Orders-Fulfilment-and-Shipping_FR.xlsx   Français
  Orders-Fulfilment-and-Shipping_ES.xlsx   Español
  Orders-Fulfilment-and-Shipping_DE.xlsx   Deutsch
  Orders-Fulfilment-and-Shipping_IT.xlsx   Italiano
  Orders-Fulfilment-and-Shipping_PT.xlsx   Português
  Orders-Fulfilment-and-Shipping_TR.xlsx   Türkçe
  Orders-Fulfilment-and-Shipping_NL.xlsx   Nederlands
  Orders-Fulfilment-and-Shipping_RU.xlsx   Русский
  Orders-Fulfilment-and-Shipping_FA.xlsx   فارسی
  Orders-Fulfilment-and-Shipping_UR.xlsx   اردو
  Orders-Fulfilment-and-Shipping_HI.xlsx   हिन्दी
  Orders-Fulfilment-and-Shipping_ZH.xlsx   中文
  Orders-Fulfilment-and-Shipping_ID.xlsx   Bahasa Indonesia
  Orders-Fulfilment-and-Shipping_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
