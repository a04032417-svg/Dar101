Wholesale Shops and Invoices
Wholesale orders, invoices, payments and margin for candle and soap makers

FILES
  Wholesale-Shops-and-Invoices_EN.xlsx   English
  Wholesale-Shops-and-Invoices_AR.xlsx   العربية
  Wholesale-Shops-and-Invoices_FR.xlsx   Français
  Wholesale-Shops-and-Invoices_ES.xlsx   Español
  Wholesale-Shops-and-Invoices_DE.xlsx   Deutsch
  Wholesale-Shops-and-Invoices_IT.xlsx   Italiano
  Wholesale-Shops-and-Invoices_PT.xlsx   Português
  Wholesale-Shops-and-Invoices_TR.xlsx   Türkçe
  Wholesale-Shops-and-Invoices_NL.xlsx   Nederlands
  Wholesale-Shops-and-Invoices_RU.xlsx   Русский
  Wholesale-Shops-and-Invoices_FA.xlsx   فارسی
  Wholesale-Shops-and-Invoices_UR.xlsx   اردو
  Wholesale-Shops-and-Invoices_HI.xlsx   हिन्दी
  Wholesale-Shops-and-Invoices_ZH.xlsx   中文
  Wholesale-Shops-and-Invoices_ID.xlsx   Bahasa Indonesia
  Wholesale-Shops-and-Invoices_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
