Handmade Product Maker Suite
Price every product right and see the true profit per batch and channel

WORKBOOKS
  01 - Formulas, Costing and Pricing: Formula costing, batch costs and pricing for candle, soap and body-care makers
  02 - Batch Production, Cure and Quality: Batch records, cure dates, yield and quality checks for candle and soap makers
  03 - Materials, Stock and Purchasing: Reorder points, lots, supplier orders and counts for candle and soap makers
  04 - Online Orders, Shipping and Returns: Order profit, packing, shipping and returns for candle and soap makers
  05 - Fairs, Markets and Custom Orders: Fair profit, stock lists, custom quotes and deposits for candle and soap makers
  06 - Wholesale Shops and Invoices: Wholesale orders, invoices, payments and margin for candle and soap makers
  07 - Range, Reviews and Growth: Product margin, reviews, repeat customers and growth for candle and soap makers
  08 - Profit, Cash and Tax: Profit, cash, payouts, sales tax and owner draw for candle and soap makers

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
