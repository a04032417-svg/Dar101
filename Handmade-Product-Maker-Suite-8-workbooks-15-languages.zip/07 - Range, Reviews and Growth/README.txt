Range, Reviews and Growth
Product margin, reviews, repeat customers and growth for candle and soap makers

FILES
  Range-Reviews-and-Growth_EN.xlsx   English
  Range-Reviews-and-Growth_AR.xlsx   العربية
  Range-Reviews-and-Growth_FR.xlsx   Français
  Range-Reviews-and-Growth_ES.xlsx   Español
  Range-Reviews-and-Growth_DE.xlsx   Deutsch
  Range-Reviews-and-Growth_IT.xlsx   Italiano
  Range-Reviews-and-Growth_PT.xlsx   Português
  Range-Reviews-and-Growth_TR.xlsx   Türkçe
  Range-Reviews-and-Growth_NL.xlsx   Nederlands
  Range-Reviews-and-Growth_RU.xlsx   Русский
  Range-Reviews-and-Growth_FA.xlsx   فارسی
  Range-Reviews-and-Growth_UR.xlsx   اردو
  Range-Reviews-and-Growth_HI.xlsx   हिन्दी
  Range-Reviews-and-Growth_ZH.xlsx   中文
  Range-Reviews-and-Growth_ID.xlsx   Bahasa Indonesia
  Range-Reviews-and-Growth_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
