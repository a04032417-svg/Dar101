Profit, Cash and Tax
Profit, cash, payouts, sales tax and owner draw for candle and soap makers

FILES
  Profit-Cash-and-Tax_EN.xlsx   English
  Profit-Cash-and-Tax_AR.xlsx   العربية
  Profit-Cash-and-Tax_FR.xlsx   Français
  Profit-Cash-and-Tax_ES.xlsx   Español
  Profit-Cash-and-Tax_DE.xlsx   Deutsch
  Profit-Cash-and-Tax_IT.xlsx   Italiano
  Profit-Cash-and-Tax_PT.xlsx   Português
  Profit-Cash-and-Tax_TR.xlsx   Türkçe
  Profit-Cash-and-Tax_NL.xlsx   Nederlands
  Profit-Cash-and-Tax_RU.xlsx   Русский
  Profit-Cash-and-Tax_FA.xlsx   فارسی
  Profit-Cash-and-Tax_UR.xlsx   اردو
  Profit-Cash-and-Tax_HI.xlsx   हिन्दी
  Profit-Cash-and-Tax_ZH.xlsx   中文
  Profit-Cash-and-Tax_ID.xlsx   Bahasa Indonesia
  Profit-Cash-and-Tax_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
