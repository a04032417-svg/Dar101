Accounting and Bookkeeping Suite
Run an accounting and bookkeeping practice from six connected Excel workbooks

WORKBOOKS
  01 - Clients and Engagements: Clients, engagements, fees per hour, onboarding, risk and capacity in one file
  02 - Time, Billing and Collections: Timesheets, invoices, receivables and collections for your practice in one file
  03 - Bookkeeping Core: The books of one client business, from journal to month-end close
  04 - Tax and Compliance: Tax deadlines, returns, notices and penalties for every client in one file
  05 - Payroll and Fixed Assets: Payroll, leave, depreciation, loans and insurance for every client in one file
  06 - Reporting and Advisory: Management reports, budgets, loan checks and advice for every client in one file

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
