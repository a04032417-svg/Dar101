Bookkeeping Core
The books of one client business, from journal to month-end close

FILES
  Bookkeeping-Core_EN.xlsx   English
  Bookkeeping-Core_AR.xlsx   العربية
  Bookkeeping-Core_FR.xlsx   Français
  Bookkeeping-Core_ES.xlsx   Español
  Bookkeeping-Core_DE.xlsx   Deutsch
  Bookkeeping-Core_IT.xlsx   Italiano
  Bookkeeping-Core_PT.xlsx   Português
  Bookkeeping-Core_TR.xlsx   Türkçe
  Bookkeeping-Core_NL.xlsx   Nederlands
  Bookkeeping-Core_RU.xlsx   Русский
  Bookkeeping-Core_FA.xlsx   فارسی
  Bookkeeping-Core_UR.xlsx   اردو
  Bookkeeping-Core_HI.xlsx   हिन्दी
  Bookkeeping-Core_ZH.xlsx   中文
  Bookkeeping-Core_ID.xlsx   Bahasa Indonesia
  Bookkeeping-Core_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
