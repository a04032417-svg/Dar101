Time, Billing and Collections
Timesheets, invoices, receivables and collections for your practice in one file

FILES
  Time-Billing-and-Collections_EN.xlsx   English
  Time-Billing-and-Collections_AR.xlsx   العربية
  Time-Billing-and-Collections_FR.xlsx   Français
  Time-Billing-and-Collections_ES.xlsx   Español
  Time-Billing-and-Collections_DE.xlsx   Deutsch
  Time-Billing-and-Collections_IT.xlsx   Italiano
  Time-Billing-and-Collections_PT.xlsx   Português
  Time-Billing-and-Collections_TR.xlsx   Türkçe
  Time-Billing-and-Collections_NL.xlsx   Nederlands
  Time-Billing-and-Collections_RU.xlsx   Русский
  Time-Billing-and-Collections_FA.xlsx   فارسی
  Time-Billing-and-Collections_UR.xlsx   اردو
  Time-Billing-and-Collections_HI.xlsx   हिन्दी
  Time-Billing-and-Collections_ZH.xlsx   中文
  Time-Billing-and-Collections_ID.xlsx   Bahasa Indonesia
  Time-Billing-and-Collections_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
