Clients and Engagements
Clients, engagements, fees per hour, onboarding, risk and capacity in one file

FILES
  Clients-and-Engagements_EN.xlsx   English
  Clients-and-Engagements_AR.xlsx   العربية
  Clients-and-Engagements_FR.xlsx   Français
  Clients-and-Engagements_ES.xlsx   Español
  Clients-and-Engagements_DE.xlsx   Deutsch
  Clients-and-Engagements_IT.xlsx   Italiano
  Clients-and-Engagements_PT.xlsx   Português
  Clients-and-Engagements_TR.xlsx   Türkçe
  Clients-and-Engagements_NL.xlsx   Nederlands
  Clients-and-Engagements_RU.xlsx   Русский
  Clients-and-Engagements_FA.xlsx   فارسی
  Clients-and-Engagements_UR.xlsx   اردو
  Clients-and-Engagements_HI.xlsx   हिन्दी
  Clients-and-Engagements_ZH.xlsx   中文
  Clients-and-Engagements_ID.xlsx   Bahasa Indonesia
  Clients-and-Engagements_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
