Delivery, Pick-up and Markets
Deliveries, pick-ups, markets and pop-ups for home bakeries and cake studios

FILES
  Delivery-Pick-up-and-Markets_EN.xlsx   English
  Delivery-Pick-up-and-Markets_AR.xlsx   العربية
  Delivery-Pick-up-and-Markets_FR.xlsx   Français
  Delivery-Pick-up-and-Markets_ES.xlsx   Español
  Delivery-Pick-up-and-Markets_DE.xlsx   Deutsch
  Delivery-Pick-up-and-Markets_IT.xlsx   Italiano
  Delivery-Pick-up-and-Markets_PT.xlsx   Português
  Delivery-Pick-up-and-Markets_TR.xlsx   Türkçe
  Delivery-Pick-up-and-Markets_NL.xlsx   Nederlands
  Delivery-Pick-up-and-Markets_RU.xlsx   Русский
  Delivery-Pick-up-and-Markets_FA.xlsx   فارسی
  Delivery-Pick-up-and-Markets_UR.xlsx   اردو
  Delivery-Pick-up-and-Markets_HI.xlsx   हिन्दी
  Delivery-Pick-up-and-Markets_ZH.xlsx   中文
  Delivery-Pick-up-and-Markets_ID.xlsx   Bahasa Indonesia
  Delivery-Pick-up-and-Markets_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
