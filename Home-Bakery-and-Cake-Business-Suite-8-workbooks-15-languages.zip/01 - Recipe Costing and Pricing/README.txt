Recipe Costing and Pricing
Recipe costing, cake quotes and margins for home bakeries and cake businesses

FILES
  Recipe-Costing-and-Pricing_EN.xlsx   English
  Recipe-Costing-and-Pricing_AR.xlsx   العربية
  Recipe-Costing-and-Pricing_FR.xlsx   Français
  Recipe-Costing-and-Pricing_ES.xlsx   Español
  Recipe-Costing-and-Pricing_DE.xlsx   Deutsch
  Recipe-Costing-and-Pricing_IT.xlsx   Italiano
  Recipe-Costing-and-Pricing_PT.xlsx   Português
  Recipe-Costing-and-Pricing_TR.xlsx   Türkçe
  Recipe-Costing-and-Pricing_NL.xlsx   Nederlands
  Recipe-Costing-and-Pricing_RU.xlsx   Русский
  Recipe-Costing-and-Pricing_FA.xlsx   فارسی
  Recipe-Costing-and-Pricing_UR.xlsx   اردو
  Recipe-Costing-and-Pricing_HI.xlsx   हिन्दी
  Recipe-Costing-and-Pricing_ZH.xlsx   中文
  Recipe-Costing-and-Pricing_ID.xlsx   Bahasa Indonesia
  Recipe-Costing-and-Pricing_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
