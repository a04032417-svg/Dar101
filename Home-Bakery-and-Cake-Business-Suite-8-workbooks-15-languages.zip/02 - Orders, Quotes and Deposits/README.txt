Orders, Quotes and Deposits
Orders, quotes, deposits and daily limits for home bakeries and cake businesses

FILES
  Orders-Quotes-and-Deposits_EN.xlsx   English
  Orders-Quotes-and-Deposits_AR.xlsx   العربية
  Orders-Quotes-and-Deposits_FR.xlsx   Français
  Orders-Quotes-and-Deposits_ES.xlsx   Español
  Orders-Quotes-and-Deposits_DE.xlsx   Deutsch
  Orders-Quotes-and-Deposits_IT.xlsx   Italiano
  Orders-Quotes-and-Deposits_PT.xlsx   Português
  Orders-Quotes-and-Deposits_TR.xlsx   Türkçe
  Orders-Quotes-and-Deposits_NL.xlsx   Nederlands
  Orders-Quotes-and-Deposits_RU.xlsx   Русский
  Orders-Quotes-and-Deposits_FA.xlsx   فارسی
  Orders-Quotes-and-Deposits_UR.xlsx   اردو
  Orders-Quotes-and-Deposits_HI.xlsx   हिन्दी
  Orders-Quotes-and-Deposits_ZH.xlsx   中文
  Orders-Quotes-and-Deposits_ID.xlsx   Bahasa Indonesia
  Orders-Quotes-and-Deposits_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
