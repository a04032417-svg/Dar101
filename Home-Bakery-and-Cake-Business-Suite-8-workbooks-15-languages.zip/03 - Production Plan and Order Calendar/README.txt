Production Plan and Order Calendar
Production plan, order calendar and oven load for home bakeries and cake studios

FILES
  Production-Plan-and-Order-Calendar_EN.xlsx   English
  Production-Plan-and-Order-Calendar_AR.xlsx   العربية
  Production-Plan-and-Order-Calendar_FR.xlsx   Français
  Production-Plan-and-Order-Calendar_ES.xlsx   Español
  Production-Plan-and-Order-Calendar_DE.xlsx   Deutsch
  Production-Plan-and-Order-Calendar_IT.xlsx   Italiano
  Production-Plan-and-Order-Calendar_PT.xlsx   Português
  Production-Plan-and-Order-Calendar_TR.xlsx   Türkçe
  Production-Plan-and-Order-Calendar_NL.xlsx   Nederlands
  Production-Plan-and-Order-Calendar_RU.xlsx   Русский
  Production-Plan-and-Order-Calendar_FA.xlsx   فارسی
  Production-Plan-and-Order-Calendar_UR.xlsx   اردو
  Production-Plan-and-Order-Calendar_HI.xlsx   हिन्दी
  Production-Plan-and-Order-Calendar_ZH.xlsx   中文
  Production-Plan-and-Order-Calendar_ID.xlsx   Bahasa Indonesia
  Production-Plan-and-Order-Calendar_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
