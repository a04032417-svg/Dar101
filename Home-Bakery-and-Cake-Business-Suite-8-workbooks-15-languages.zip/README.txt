Home Bakery and Cake Business Suite
Price every cake right, plan every bake and see your real profit per order

WORKBOOKS
  01 - Recipe Costing and Pricing: Recipe costing, cake quotes and margins for home bakeries and cake businesses
  02 - Orders, Quotes and Deposits: Orders, quotes, deposits and daily limits for home bakeries and cake businesses
  03 - Production Plan and Order Calendar: Production plan, order calendar and oven load for home bakeries and cake studios
  04 - Ingredient Stock and Waste: Stock, purchasing, supplier prices and waste for home bakeries and cake studios
  05 - Allergens, Labels and Product Range: Allergens, labels, batch codes and cleaning for home bakeries and cake studios
  06 - Delivery, Pick-up and Markets: Deliveries, pick-ups, markets and pop-ups for home bakeries and cake studios
  07 - Wholesale Accounts and Client Payments: Wholesale accounts, invoices and client payments for home bakeries
  08 - Profit, Cash Flow and Growth: Profit, cash flow and growth for home bakeries and cake businesses

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
