Allergens, Labels and Product Range
Allergens, labels, batch codes and cleaning for home bakeries and cake studios

FILES
  Allergens-Labels-and-Product-Range_EN.xlsx   English
  Allergens-Labels-and-Product-Range_AR.xlsx   العربية
  Allergens-Labels-and-Product-Range_FR.xlsx   Français
  Allergens-Labels-and-Product-Range_ES.xlsx   Español
  Allergens-Labels-and-Product-Range_DE.xlsx   Deutsch
  Allergens-Labels-and-Product-Range_IT.xlsx   Italiano
  Allergens-Labels-and-Product-Range_PT.xlsx   Português
  Allergens-Labels-and-Product-Range_TR.xlsx   Türkçe
  Allergens-Labels-and-Product-Range_NL.xlsx   Nederlands
  Allergens-Labels-and-Product-Range_RU.xlsx   Русский
  Allergens-Labels-and-Product-Range_FA.xlsx   فارسی
  Allergens-Labels-and-Product-Range_UR.xlsx   اردو
  Allergens-Labels-and-Product-Range_HI.xlsx   हिन्दी
  Allergens-Labels-and-Product-Range_ZH.xlsx   中文
  Allergens-Labels-and-Product-Range_ID.xlsx   Bahasa Indonesia
  Allergens-Labels-and-Product-Range_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
