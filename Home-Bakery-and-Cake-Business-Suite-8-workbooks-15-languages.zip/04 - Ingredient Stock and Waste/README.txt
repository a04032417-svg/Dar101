Ingredient Stock and Waste
Stock, purchasing, supplier prices and waste for home bakeries and cake studios

FILES
  Ingredient-Stock-and-Waste_EN.xlsx   English
  Ingredient-Stock-and-Waste_AR.xlsx   العربية
  Ingredient-Stock-and-Waste_FR.xlsx   Français
  Ingredient-Stock-and-Waste_ES.xlsx   Español
  Ingredient-Stock-and-Waste_DE.xlsx   Deutsch
  Ingredient-Stock-and-Waste_IT.xlsx   Italiano
  Ingredient-Stock-and-Waste_PT.xlsx   Português
  Ingredient-Stock-and-Waste_TR.xlsx   Türkçe
  Ingredient-Stock-and-Waste_NL.xlsx   Nederlands
  Ingredient-Stock-and-Waste_RU.xlsx   Русский
  Ingredient-Stock-and-Waste_FA.xlsx   فارسی
  Ingredient-Stock-and-Waste_UR.xlsx   اردو
  Ingredient-Stock-and-Waste_HI.xlsx   हिन्दी
  Ingredient-Stock-and-Waste_ZH.xlsx   中文
  Ingredient-Stock-and-Waste_ID.xlsx   Bahasa Indonesia
  Ingredient-Stock-and-Waste_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
