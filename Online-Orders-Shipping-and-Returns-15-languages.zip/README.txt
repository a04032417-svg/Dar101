Online Orders, Shipping and Returns
Order profit, packing, shipping and returns for candle and soap makers

FILES
  Online-Orders-Shipping-and-Returns_EN.xlsx   English
  Online-Orders-Shipping-and-Returns_AR.xlsx   العربية
  Online-Orders-Shipping-and-Returns_FR.xlsx   Français
  Online-Orders-Shipping-and-Returns_ES.xlsx   Español
  Online-Orders-Shipping-and-Returns_DE.xlsx   Deutsch
  Online-Orders-Shipping-and-Returns_IT.xlsx   Italiano
  Online-Orders-Shipping-and-Returns_PT.xlsx   Português
  Online-Orders-Shipping-and-Returns_TR.xlsx   Türkçe
  Online-Orders-Shipping-and-Returns_NL.xlsx   Nederlands
  Online-Orders-Shipping-and-Returns_RU.xlsx   Русский
  Online-Orders-Shipping-and-Returns_FA.xlsx   فارسی
  Online-Orders-Shipping-and-Returns_UR.xlsx   اردو
  Online-Orders-Shipping-and-Returns_HI.xlsx   हिन्दी
  Online-Orders-Shipping-and-Returns_ZH.xlsx   中文
  Online-Orders-Shipping-and-Returns_ID.xlsx   Bahasa Indonesia
  Online-Orders-Shipping-and-Returns_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
