Batch Production, Cure and Quality
Batch records, cure dates, yield and quality checks for candle and soap makers

FILES
  Batch-Production-Cure-and-Quality_EN.xlsx   English
  Batch-Production-Cure-and-Quality_AR.xlsx   العربية
  Batch-Production-Cure-and-Quality_FR.xlsx   Français
  Batch-Production-Cure-and-Quality_ES.xlsx   Español
  Batch-Production-Cure-and-Quality_DE.xlsx   Deutsch
  Batch-Production-Cure-and-Quality_IT.xlsx   Italiano
  Batch-Production-Cure-and-Quality_PT.xlsx   Português
  Batch-Production-Cure-and-Quality_TR.xlsx   Türkçe
  Batch-Production-Cure-and-Quality_NL.xlsx   Nederlands
  Batch-Production-Cure-and-Quality_RU.xlsx   Русский
  Batch-Production-Cure-and-Quality_FA.xlsx   فارسی
  Batch-Production-Cure-and-Quality_UR.xlsx   اردو
  Batch-Production-Cure-and-Quality_HI.xlsx   हिन्दी
  Batch-Production-Cure-and-Quality_ZH.xlsx   中文
  Batch-Production-Cure-and-Quality_ID.xlsx   Bahasa Indonesia
  Batch-Production-Cure-and-Quality_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
