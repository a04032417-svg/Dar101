Technician Pay and Productivity
Pay your technicians, collect rent and see who is productive

FILES
  Technician-Pay-and-Productivity_EN.xlsx   English
  Technician-Pay-and-Productivity_AR.xlsx   العربية
  Technician-Pay-and-Productivity_FR.xlsx   Français
  Technician-Pay-and-Productivity_ES.xlsx   Español
  Technician-Pay-and-Productivity_DE.xlsx   Deutsch
  Technician-Pay-and-Productivity_IT.xlsx   Italiano
  Technician-Pay-and-Productivity_PT.xlsx   Português
  Technician-Pay-and-Productivity_TR.xlsx   Türkçe
  Technician-Pay-and-Productivity_NL.xlsx   Nederlands
  Technician-Pay-and-Productivity_RU.xlsx   Русский
  Technician-Pay-and-Productivity_FA.xlsx   فارسی
  Technician-Pay-and-Productivity_UR.xlsx   اردو
  Technician-Pay-and-Productivity_HI.xlsx   हिन्दी
  Technician-Pay-and-Productivity_ZH.xlsx   中文
  Technician-Pay-and-Productivity_ID.xlsx   Bahasa Indonesia
  Technician-Pay-and-Productivity_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
