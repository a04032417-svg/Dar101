Owner Accounting & Statements
Owner ledgers, statements, fees, payouts, reserves and budgets for every owner

FILES
  Owner-Accounting-Statements_EN.xlsx   English
  Owner-Accounting-Statements_AR.xlsx   العربية
  Owner-Accounting-Statements_FR.xlsx   Français
  Owner-Accounting-Statements_ES.xlsx   Español
  Owner-Accounting-Statements_DE.xlsx   Deutsch
  Owner-Accounting-Statements_IT.xlsx   Italiano
  Owner-Accounting-Statements_PT.xlsx   Português
  Owner-Accounting-Statements_TR.xlsx   Türkçe
  Owner-Accounting-Statements_NL.xlsx   Nederlands
  Owner-Accounting-Statements_RU.xlsx   Русский
  Owner-Accounting-Statements_FA.xlsx   فارسی
  Owner-Accounting-Statements_UR.xlsx   اردو
  Owner-Accounting-Statements_HI.xlsx   हिन्दी
  Owner-Accounting-Statements_ZH.xlsx   中文
  Owner-Accounting-Statements_ID.xlsx   Bahasa Indonesia
  Owner-Accounting-Statements_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
