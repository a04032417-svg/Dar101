Creators and Partnerships
Run creator campaigns, contracts and payments for every brand you manage

FILES
  Creators-and-Partnerships_EN.xlsx   English
  Creators-and-Partnerships_AR.xlsx   العربية
  Creators-and-Partnerships_FR.xlsx   Français
  Creators-and-Partnerships_ES.xlsx   Español
  Creators-and-Partnerships_DE.xlsx   Deutsch
  Creators-and-Partnerships_IT.xlsx   Italiano
  Creators-and-Partnerships_PT.xlsx   Português
  Creators-and-Partnerships_TR.xlsx   Türkçe
  Creators-and-Partnerships_NL.xlsx   Nederlands
  Creators-and-Partnerships_RU.xlsx   Русский
  Creators-and-Partnerships_FA.xlsx   فارسی
  Creators-and-Partnerships_UR.xlsx   اردو
  Creators-and-Partnerships_HI.xlsx   हिन्दी
  Creators-and-Partnerships_ZH.xlsx   中文
  Creators-and-Partnerships_ID.xlsx   Bahasa Indonesia
  Creators-and-Partnerships_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
