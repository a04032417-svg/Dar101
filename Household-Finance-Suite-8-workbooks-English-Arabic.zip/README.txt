Household Finance Suite
See your cash low point before every payday and give each paycheck a job

WORKBOOKS
  01 - Money Plan and Paychecks: Give every paycheck a job and see the cash low point before payday
  02 - Bills, Subscriptions and Due Dates: See every bill due before payday and the subscriptions worth a second look
  03 - Spending Tracker and Groceries: Catch an overspend before month end, with groceries tracked week by week
  04 - Debt Payoff Planner: Compare snowball and avalanche payoff and see your estimated payoff date
  05 - Savings Goals and Sinking Funds: Set aside the right amount per paycheck for every goal and yearly cost
  06 - Net Worth and Accounts: See net worth by month and what each partner moves to the joint account
  07 - Partners, Kids and Shared Costs: Split shared costs fairly and test what happens if one income stops
  08 - Big Purchases, Tax and Year Review: Plan the car, the move and the tax papers, then review your year

Each folder holds the workbook in English and in Arabic, and a copy of each full of sample data. / كل مجلد فيه ملف العمل بالإنجليزية وبالعربية، ونسخة من كل منهما مملوءة ببيانات تجريبية.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
