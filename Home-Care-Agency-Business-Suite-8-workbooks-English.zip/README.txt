Home Care Agency Business Suite
Find the clients that lose money and see cash trouble 13 weeks ahead

WORKBOOKS
  01 - Enquiries, Quotes and Agreements: Price every quote above your margin and see why enquiries are lost
  02 - Schedule, Matching and Cover: Fill open shifts with the best match and see overtime before payroll
  03 - Visits, Hours and Travel: Find the hours you pay for but never bill, and which visits run late
  04 - Caregiver Payroll and Overtime: Check every pay line and see who crosses the overtime line this week
  05 - Client Invoices, Deposits and Payers: Phone the right balances first and track every payer claim to payment
  06 - Recruiting, Onboarding and Renewals: Know which source brings caregivers who stay, and which renewals are due
  07 - Client Margin and Hours Growth: See which clients earn less than your target, and the rate that fixes it
  08 - Owner Money and Business Health: See cash 13 weeks ahead and the largest owner draw above your floor

Each folder holds the workbook and a copy full of sample data.
Standard .xlsx files for Microsoft Excel, Google Sheets and LibreOffice Calc. No macros.
Google Sheets: open Google-Sheets-copy-links.txt and press "Make a copy" on each link.
Personal use licence for one business.
