Analytics and Reporting
Results and reports for every brand you manage in one file

FILES
  Analytics-and-Reporting_EN.xlsx   English
  Analytics-and-Reporting_AR.xlsx   العربية
  Analytics-and-Reporting_FR.xlsx   Français
  Analytics-and-Reporting_ES.xlsx   Español
  Analytics-and-Reporting_DE.xlsx   Deutsch
  Analytics-and-Reporting_IT.xlsx   Italiano
  Analytics-and-Reporting_PT.xlsx   Português
  Analytics-and-Reporting_TR.xlsx   Türkçe
  Analytics-and-Reporting_NL.xlsx   Nederlands
  Analytics-and-Reporting_RU.xlsx   Русский
  Analytics-and-Reporting_FA.xlsx   فارسی
  Analytics-and-Reporting_UR.xlsx   اردو
  Analytics-and-Reporting_HI.xlsx   हिन्दी
  Analytics-and-Reporting_ZH.xlsx   中文
  Analytics-and-Reporting_ID.xlsx   Bahasa Indonesia
  Analytics-and-Reporting_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
