Risks, Issues, Changes and Decisions
Control project risks, issues, changes, decisions and assumptions

FILES
  Risks-Issues-Changes-and-Decisions_EN.xlsx   English
  Risks-Issues-Changes-and-Decisions_AR.xlsx   العربية
  Risks-Issues-Changes-and-Decisions_FR.xlsx   Français
  Risks-Issues-Changes-and-Decisions_ES.xlsx   Español
  Risks-Issues-Changes-and-Decisions_DE.xlsx   Deutsch
  Risks-Issues-Changes-and-Decisions_IT.xlsx   Italiano
  Risks-Issues-Changes-and-Decisions_PT.xlsx   Português
  Risks-Issues-Changes-and-Decisions_TR.xlsx   Türkçe
  Risks-Issues-Changes-and-Decisions_NL.xlsx   Nederlands
  Risks-Issues-Changes-and-Decisions_RU.xlsx   Русский
  Risks-Issues-Changes-and-Decisions_FA.xlsx   فارسی
  Risks-Issues-Changes-and-Decisions_UR.xlsx   اردو
  Risks-Issues-Changes-and-Decisions_HI.xlsx   हिन्दी
  Risks-Issues-Changes-and-Decisions_ZH.xlsx   中文
  Risks-Issues-Changes-and-Decisions_ID.xlsx   Bahasa Indonesia
  Risks-Issues-Changes-and-Decisions_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
