Projects and Site Diary
Project schedule, site diary and delay claims for every job you build

FILES
  Projects-and-Site-Diary_EN.xlsx   English
  Projects-and-Site-Diary_AR.xlsx   العربية
  Projects-and-Site-Diary_FR.xlsx   Français
  Projects-and-Site-Diary_ES.xlsx   Español
  Projects-and-Site-Diary_DE.xlsx   Deutsch
  Projects-and-Site-Diary_IT.xlsx   Italiano
  Projects-and-Site-Diary_PT.xlsx   Português
  Projects-and-Site-Diary_TR.xlsx   Türkçe
  Projects-and-Site-Diary_NL.xlsx   Nederlands
  Projects-and-Site-Diary_RU.xlsx   Русский
  Projects-and-Site-Diary_FA.xlsx   فارسی
  Projects-and-Site-Diary_UR.xlsx   اردو
  Projects-and-Site-Diary_HI.xlsx   हिन्दी
  Projects-and-Site-Diary_ZH.xlsx   中文
  Projects-and-Site-Diary_ID.xlsx   Bahasa Indonesia
  Projects-and-Site-Diary_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
