Returns and Customer Service
Returns, refunds, tickets and reviews: see what each return really costs

FILES
  Returns-and-Customer-Service_EN.xlsx   English
  Returns-and-Customer-Service_AR.xlsx   العربية
  Returns-and-Customer-Service_FR.xlsx   Français
  Returns-and-Customer-Service_ES.xlsx   Español
  Returns-and-Customer-Service_DE.xlsx   Deutsch
  Returns-and-Customer-Service_IT.xlsx   Italiano
  Returns-and-Customer-Service_PT.xlsx   Português
  Returns-and-Customer-Service_TR.xlsx   Türkçe
  Returns-and-Customer-Service_NL.xlsx   Nederlands
  Returns-and-Customer-Service_RU.xlsx   Русский
  Returns-and-Customer-Service_FA.xlsx   فارسی
  Returns-and-Customer-Service_UR.xlsx   اردو
  Returns-and-Customer-Service_HI.xlsx   हिन्दी
  Returns-and-Customer-Service_ZH.xlsx   中文
  Returns-and-Customer-Service_ID.xlsx   Bahasa Indonesia
  Returns-and-Customer-Service_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
