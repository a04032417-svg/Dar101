Sales Channels and Analytics
Channel profit, payouts, products, customers and wholesale

FILES
  Sales-Channels-and-Analytics_EN.xlsx   English
  Sales-Channels-and-Analytics_AR.xlsx   العربية
  Sales-Channels-and-Analytics_FR.xlsx   Français
  Sales-Channels-and-Analytics_ES.xlsx   Español
  Sales-Channels-and-Analytics_DE.xlsx   Deutsch
  Sales-Channels-and-Analytics_IT.xlsx   Italiano
  Sales-Channels-and-Analytics_PT.xlsx   Português
  Sales-Channels-and-Analytics_TR.xlsx   Türkçe
  Sales-Channels-and-Analytics_NL.xlsx   Nederlands
  Sales-Channels-and-Analytics_RU.xlsx   Русский
  Sales-Channels-and-Analytics_FA.xlsx   فارسی
  Sales-Channels-and-Analytics_UR.xlsx   اردو
  Sales-Channels-and-Analytics_HI.xlsx   हिन्दी
  Sales-Channels-and-Analytics_ZH.xlsx   中文
  Sales-Channels-and-Analytics_ID.xlsx   Bahasa Indonesia
  Sales-Channels-and-Analytics_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
