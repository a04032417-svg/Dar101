Online Seller Suite
Know your real profit on every product and channel – and never run out of stock

WORKBOOKS
  01 - Products, Costs and Pricing: Know the real margin of every product on every channel
  02 - Inventory and Stock: Stock levels, reorder points, counts and dead stock for an online shop
  03 - Purchasing and Suppliers: Control purchase orders, landed cost, suppliers and payments
  04 - Orders, Fulfilment and Shipping: Pick, pack and ship every order on time and see what shipping costs
  05 - Returns and Customer Service: Returns, refunds, tickets and reviews: see what each return really costs
  06 - Marketing, Ads and Promotions: Ad return, promotions, discount codes, e-mail and creators in one workbook
  07 - Sales Channels and Analytics: Channel profit, payouts, products, customers and wholesale
  08 - Online Seller Finance and Cash: Profit, cash in 13 weeks, sales tax and break-even in one file

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
