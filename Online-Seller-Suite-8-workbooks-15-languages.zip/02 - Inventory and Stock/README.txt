Inventory and Stock
Stock levels, reorder points, counts and dead stock for an online shop

FILES
  Inventory-and-Stock_EN.xlsx   English
  Inventory-and-Stock_AR.xlsx   العربية
  Inventory-and-Stock_FR.xlsx   Français
  Inventory-and-Stock_ES.xlsx   Español
  Inventory-and-Stock_DE.xlsx   Deutsch
  Inventory-and-Stock_IT.xlsx   Italiano
  Inventory-and-Stock_PT.xlsx   Português
  Inventory-and-Stock_TR.xlsx   Türkçe
  Inventory-and-Stock_NL.xlsx   Nederlands
  Inventory-and-Stock_RU.xlsx   Русский
  Inventory-and-Stock_FA.xlsx   فارسی
  Inventory-and-Stock_UR.xlsx   اردو
  Inventory-and-Stock_HI.xlsx   हिन्दी
  Inventory-and-Stock_ZH.xlsx   中文
  Inventory-and-Stock_ID.xlsx   Bahasa Indonesia
  Inventory-and-Stock_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
