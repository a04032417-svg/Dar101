Rebooking, Referrals and Reviews
Bring clients back on time and answer every review

FILES
  Rebooking-Referrals-and-Reviews_EN.xlsx   English
  Rebooking-Referrals-and-Reviews_AR.xlsx   العربية
  Rebooking-Referrals-and-Reviews_FR.xlsx   Français
  Rebooking-Referrals-and-Reviews_ES.xlsx   Español
  Rebooking-Referrals-and-Reviews_DE.xlsx   Deutsch
  Rebooking-Referrals-and-Reviews_IT.xlsx   Italiano
  Rebooking-Referrals-and-Reviews_PT.xlsx   Português
  Rebooking-Referrals-and-Reviews_TR.xlsx   Türkçe
  Rebooking-Referrals-and-Reviews_NL.xlsx   Nederlands
  Rebooking-Referrals-and-Reviews_RU.xlsx   Русский
  Rebooking-Referrals-and-Reviews_FA.xlsx   فارسی
  Rebooking-Referrals-and-Reviews_UR.xlsx   اردو
  Rebooking-Referrals-and-Reviews_HI.xlsx   हिन्दी
  Rebooking-Referrals-and-Reviews_ZH.xlsx   中文
  Rebooking-Referrals-and-Reviews_ID.xlsx   Bahasa Indonesia
  Rebooking-Referrals-and-Reviews_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
