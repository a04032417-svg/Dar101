Takings, Profit, Cash and Growth
Close the till, see the profit and plan cash and growth

FILES
  Takings-Profit-Cash-and-Growth_EN.xlsx   English
  Takings-Profit-Cash-and-Growth_AR.xlsx   العربية
  Takings-Profit-Cash-and-Growth_FR.xlsx   Français
  Takings-Profit-Cash-and-Growth_ES.xlsx   Español
  Takings-Profit-Cash-and-Growth_DE.xlsx   Deutsch
  Takings-Profit-Cash-and-Growth_IT.xlsx   Italiano
  Takings-Profit-Cash-and-Growth_PT.xlsx   Português
  Takings-Profit-Cash-and-Growth_TR.xlsx   Türkçe
  Takings-Profit-Cash-and-Growth_NL.xlsx   Nederlands
  Takings-Profit-Cash-and-Growth_RU.xlsx   Русский
  Takings-Profit-Cash-and-Growth_FA.xlsx   فارسی
  Takings-Profit-Cash-and-Growth_UR.xlsx   اردو
  Takings-Profit-Cash-and-Growth_HI.xlsx   हिन्दी
  Takings-Profit-Cash-and-Growth_ZH.xlsx   中文
  Takings-Profit-Cash-and-Growth_ID.xlsx   Bahasa Indonesia
  Takings-Profit-Cash-and-Growth_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
