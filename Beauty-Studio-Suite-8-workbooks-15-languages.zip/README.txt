Beauty Studio Suite
Price every service right, fill every chair and keep clients coming back

WORKBOOKS
  01 - Service Menu, Pricing and Margins: Price every service so each hour of a chair earns what it should
  02 - Appointment Book and Chair Capacity: Fill every chair hour and stop losing money to no-shows
  03 - Clients, Consent and Patch Tests: Keep every client record ready before the visit
  04 - Rebooking, Referrals and Reviews: Bring clients back on time and answer every review
  05 - Memberships, Packages and Gift Cards: Keep every prepaid balance honest
  06 - Technician Pay and Productivity: Pay your technicians, collect rent and see who is productive
  07 - Stock, Back-bar and Hygiene Logs: Keep the studio stocked and clean
  08 - Takings, Profit, Cash and Growth: Close the till, see the profit and plan cash and growth

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
