Clients, Consent and Patch Tests
Keep every client record ready before the visit

FILES
  Clients-Consent-and-Patch-Tests_EN.xlsx   English
  Clients-Consent-and-Patch-Tests_AR.xlsx   العربية
  Clients-Consent-and-Patch-Tests_FR.xlsx   Français
  Clients-Consent-and-Patch-Tests_ES.xlsx   Español
  Clients-Consent-and-Patch-Tests_DE.xlsx   Deutsch
  Clients-Consent-and-Patch-Tests_IT.xlsx   Italiano
  Clients-Consent-and-Patch-Tests_PT.xlsx   Português
  Clients-Consent-and-Patch-Tests_TR.xlsx   Türkçe
  Clients-Consent-and-Patch-Tests_NL.xlsx   Nederlands
  Clients-Consent-and-Patch-Tests_RU.xlsx   Русский
  Clients-Consent-and-Patch-Tests_FA.xlsx   فارسی
  Clients-Consent-and-Patch-Tests_UR.xlsx   اردو
  Clients-Consent-and-Patch-Tests_HI.xlsx   हिन्दी
  Clients-Consent-and-Patch-Tests_ZH.xlsx   中文
  Clients-Consent-and-Patch-Tests_ID.xlsx   Bahasa Indonesia
  Clients-Consent-and-Patch-Tests_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
