Appointment Book and Chair Capacity
Fill every chair hour and stop losing money to no-shows

FILES
  Appointment-Book-and-Chair-Capacity_EN.xlsx   English
  Appointment-Book-and-Chair-Capacity_AR.xlsx   العربية
  Appointment-Book-and-Chair-Capacity_FR.xlsx   Français
  Appointment-Book-and-Chair-Capacity_ES.xlsx   Español
  Appointment-Book-and-Chair-Capacity_DE.xlsx   Deutsch
  Appointment-Book-and-Chair-Capacity_IT.xlsx   Italiano
  Appointment-Book-and-Chair-Capacity_PT.xlsx   Português
  Appointment-Book-and-Chair-Capacity_TR.xlsx   Türkçe
  Appointment-Book-and-Chair-Capacity_NL.xlsx   Nederlands
  Appointment-Book-and-Chair-Capacity_RU.xlsx   Русский
  Appointment-Book-and-Chair-Capacity_FA.xlsx   فارسی
  Appointment-Book-and-Chair-Capacity_UR.xlsx   اردو
  Appointment-Book-and-Chair-Capacity_HI.xlsx   हिन्दी
  Appointment-Book-and-Chair-Capacity_ZH.xlsx   中文
  Appointment-Book-and-Chair-Capacity_ID.xlsx   Bahasa Indonesia
  Appointment-Book-and-Chair-Capacity_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
