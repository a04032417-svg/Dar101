Stock, Back-bar and Hygiene Logs
Keep the studio stocked and clean

FILES
  Stock-Back-bar-and-Hygiene-Logs_EN.xlsx   English
  Stock-Back-bar-and-Hygiene-Logs_AR.xlsx   العربية
  Stock-Back-bar-and-Hygiene-Logs_FR.xlsx   Français
  Stock-Back-bar-and-Hygiene-Logs_ES.xlsx   Español
  Stock-Back-bar-and-Hygiene-Logs_DE.xlsx   Deutsch
  Stock-Back-bar-and-Hygiene-Logs_IT.xlsx   Italiano
  Stock-Back-bar-and-Hygiene-Logs_PT.xlsx   Português
  Stock-Back-bar-and-Hygiene-Logs_TR.xlsx   Türkçe
  Stock-Back-bar-and-Hygiene-Logs_NL.xlsx   Nederlands
  Stock-Back-bar-and-Hygiene-Logs_RU.xlsx   Русский
  Stock-Back-bar-and-Hygiene-Logs_FA.xlsx   فارسی
  Stock-Back-bar-and-Hygiene-Logs_UR.xlsx   اردو
  Stock-Back-bar-and-Hygiene-Logs_HI.xlsx   हिन्दी
  Stock-Back-bar-and-Hygiene-Logs_ZH.xlsx   中文
  Stock-Back-bar-and-Hygiene-Logs_ID.xlsx   Bahasa Indonesia
  Stock-Back-bar-and-Hygiene-Logs_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
