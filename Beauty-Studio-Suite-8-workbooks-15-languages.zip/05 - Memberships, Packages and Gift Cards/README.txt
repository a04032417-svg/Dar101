Memberships, Packages and Gift Cards
Keep every prepaid balance honest

FILES
  Memberships-Packages-and-Gift-Cards_EN.xlsx   English
  Memberships-Packages-and-Gift-Cards_AR.xlsx   العربية
  Memberships-Packages-and-Gift-Cards_FR.xlsx   Français
  Memberships-Packages-and-Gift-Cards_ES.xlsx   Español
  Memberships-Packages-and-Gift-Cards_DE.xlsx   Deutsch
  Memberships-Packages-and-Gift-Cards_IT.xlsx   Italiano
  Memberships-Packages-and-Gift-Cards_PT.xlsx   Português
  Memberships-Packages-and-Gift-Cards_TR.xlsx   Türkçe
  Memberships-Packages-and-Gift-Cards_NL.xlsx   Nederlands
  Memberships-Packages-and-Gift-Cards_RU.xlsx   Русский
  Memberships-Packages-and-Gift-Cards_FA.xlsx   فارسی
  Memberships-Packages-and-Gift-Cards_UR.xlsx   اردو
  Memberships-Packages-and-Gift-Cards_HI.xlsx   हिन्दी
  Memberships-Packages-and-Gift-Cards_ZH.xlsx   中文
  Memberships-Packages-and-Gift-Cards_ID.xlsx   Bahasa Indonesia
  Memberships-Packages-and-Gift-Cards_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
