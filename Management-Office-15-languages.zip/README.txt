Management Office
Win and keep owners, run your team and see the company profit

FILES
  Management-Office_EN.xlsx   English
  Management-Office_AR.xlsx   العربية
  Management-Office_FR.xlsx   Français
  Management-Office_ES.xlsx   Español
  Management-Office_DE.xlsx   Deutsch
  Management-Office_IT.xlsx   Italiano
  Management-Office_PT.xlsx   Português
  Management-Office_TR.xlsx   Türkçe
  Management-Office_NL.xlsx   Nederlands
  Management-Office_RU.xlsx   Русский
  Management-Office_FA.xlsx   فارسی
  Management-Office_UR.xlsx   اردو
  Management-Office_HI.xlsx   हिन्दी
  Management-Office_ZH.xlsx   中文
  Management-Office_ID.xlsx   Bahasa Indonesia
  Management-Office_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
