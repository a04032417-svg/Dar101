HVAC and Plumbing Contractor Suite
See the profit on every job, who still owes you and when cash runs low

WORKBOOKS
  01 - Calls, Dispatch and Jobs: See every missed call, plan each van day and catch a permit holding a job
  02 - Price Book, Estimates and Options: Price every task from cost and see which estimates to chase first
  03 - Job Costing, Margin and Callbacks: See which jobs lost money, what callbacks cost and which prices to fix
  04 - Technicians- Hours, Pay and Capacity: Know what a technician hour costs, who has room and when to hire
  05 - Parts, Van Stock and Vehicles: See what is on each van, what it costs to run and which parts went unbilled
  06 - Sites, Equipment and Agreements: Know which agreements renew this month and which tune-ups are overdue
  07 - Invoices, Collections and Cash: Chase the biggest overdue invoices first and see the cash dip before it comes
  08 - Leads, Reviews, Renewals, Scorecard: Rank lead sources by cost per booked job and read one Monday scorecard

Each folder holds the workbook and a copy full of sample data.
Standard .xlsx files for Microsoft Excel, Google Sheets and LibreOffice Calc. No macros.
Google Sheets: open Google-Sheets-copy-links.txt and press "Make a copy" on each link.
Personal use licence for one business.
