Company Finance and Performance
Profit, overheads, order book and cash in one place

FILES
  Company-Finance-and-Performance_EN.xlsx   English
  Company-Finance-and-Performance_AR.xlsx   العربية
  Company-Finance-and-Performance_FR.xlsx   Français
  Company-Finance-and-Performance_ES.xlsx   Español
  Company-Finance-and-Performance_DE.xlsx   Deutsch
  Company-Finance-and-Performance_IT.xlsx   Italiano
  Company-Finance-and-Performance_PT.xlsx   Português
  Company-Finance-and-Performance_TR.xlsx   Türkçe
  Company-Finance-and-Performance_NL.xlsx   Nederlands
  Company-Finance-and-Performance_RU.xlsx   Русский
  Company-Finance-and-Performance_FA.xlsx   فارسی
  Company-Finance-and-Performance_UR.xlsx   اردو
  Company-Finance-and-Performance_HI.xlsx   हिन्दी
  Company-Finance-and-Performance_ZH.xlsx   中文
  Company-Finance-and-Performance_ID.xlsx   Bahasa Indonesia
  Company-Finance-and-Performance_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
