Suppliers, Scorecards and Service Fees
Know which suppliers earn their place and which fees pay

FILES
  Suppliers-Scorecards-and-Service-Fees_EN.xlsx   English
  Suppliers-Scorecards-and-Service-Fees_AR.xlsx   العربية
  Suppliers-Scorecards-and-Service-Fees_FR.xlsx   Français
  Suppliers-Scorecards-and-Service-Fees_ES.xlsx   Español
  Suppliers-Scorecards-and-Service-Fees_DE.xlsx   Deutsch
  Suppliers-Scorecards-and-Service-Fees_IT.xlsx   Italiano
  Suppliers-Scorecards-and-Service-Fees_PT.xlsx   Português
  Suppliers-Scorecards-and-Service-Fees_TR.xlsx   Türkçe
  Suppliers-Scorecards-and-Service-Fees_NL.xlsx   Nederlands
  Suppliers-Scorecards-and-Service-Fees_RU.xlsx   Русский
  Suppliers-Scorecards-and-Service-Fees_FA.xlsx   فارسی
  Suppliers-Scorecards-and-Service-Fees_UR.xlsx   اردو
  Suppliers-Scorecards-and-Service-Fees_HI.xlsx   हिन्दी
  Suppliers-Scorecards-and-Service-Fees_ZH.xlsx   中文
  Suppliers-Scorecards-and-Service-Fees_ID.xlsx   Bahasa Indonesia
  Suppliers-Scorecards-and-Service-Fees_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
