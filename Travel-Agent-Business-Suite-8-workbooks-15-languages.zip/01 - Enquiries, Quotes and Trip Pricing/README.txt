Enquiries, Quotes and Trip Pricing
Turn enquiries into booked trips at a margin that pays

FILES
  Enquiries-Quotes-and-Trip-Pricing_EN.xlsx   English
  Enquiries-Quotes-and-Trip-Pricing_AR.xlsx   العربية
  Enquiries-Quotes-and-Trip-Pricing_FR.xlsx   Français
  Enquiries-Quotes-and-Trip-Pricing_ES.xlsx   Español
  Enquiries-Quotes-and-Trip-Pricing_DE.xlsx   Deutsch
  Enquiries-Quotes-and-Trip-Pricing_IT.xlsx   Italiano
  Enquiries-Quotes-and-Trip-Pricing_PT.xlsx   Português
  Enquiries-Quotes-and-Trip-Pricing_TR.xlsx   Türkçe
  Enquiries-Quotes-and-Trip-Pricing_NL.xlsx   Nederlands
  Enquiries-Quotes-and-Trip-Pricing_RU.xlsx   Русский
  Enquiries-Quotes-and-Trip-Pricing_FA.xlsx   فارسی
  Enquiries-Quotes-and-Trip-Pricing_UR.xlsx   اردو
  Enquiries-Quotes-and-Trip-Pricing_HI.xlsx   हिन्दी
  Enquiries-Quotes-and-Trip-Pricing_ZH.xlsx   中文
  Enquiries-Quotes-and-Trip-Pricing_ID.xlsx   Bahasa Indonesia
  Enquiries-Quotes-and-Trip-Pricing_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
