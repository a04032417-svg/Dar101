Commissions and Host Splits
Know what every trip earns and chase every unpaid commission

FILES
  Commissions-and-Host-Splits_EN.xlsx   English
  Commissions-and-Host-Splits_AR.xlsx   العربية
  Commissions-and-Host-Splits_FR.xlsx   Français
  Commissions-and-Host-Splits_ES.xlsx   Español
  Commissions-and-Host-Splits_DE.xlsx   Deutsch
  Commissions-and-Host-Splits_IT.xlsx   Italiano
  Commissions-and-Host-Splits_PT.xlsx   Português
  Commissions-and-Host-Splits_TR.xlsx   Türkçe
  Commissions-and-Host-Splits_NL.xlsx   Nederlands
  Commissions-and-Host-Splits_RU.xlsx   Русский
  Commissions-and-Host-Splits_FA.xlsx   فارسی
  Commissions-and-Host-Splits_UR.xlsx   اردو
  Commissions-and-Host-Splits_HI.xlsx   हिन्दी
  Commissions-and-Host-Splits_ZH.xlsx   中文
  Commissions-and-Host-Splits_ID.xlsx   Bahasa Indonesia
  Commissions-and-Host-Splits_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
