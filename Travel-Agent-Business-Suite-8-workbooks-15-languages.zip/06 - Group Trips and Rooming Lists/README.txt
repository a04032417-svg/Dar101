Group Trips and Rooming Lists
Place every traveller, room and payment of a group trip

FILES
  Group-Trips-and-Rooming-Lists_EN.xlsx   English
  Group-Trips-and-Rooming-Lists_AR.xlsx   العربية
  Group-Trips-and-Rooming-Lists_FR.xlsx   Français
  Group-Trips-and-Rooming-Lists_ES.xlsx   Español
  Group-Trips-and-Rooming-Lists_DE.xlsx   Deutsch
  Group-Trips-and-Rooming-Lists_IT.xlsx   Italiano
  Group-Trips-and-Rooming-Lists_PT.xlsx   Português
  Group-Trips-and-Rooming-Lists_TR.xlsx   Türkçe
  Group-Trips-and-Rooming-Lists_NL.xlsx   Nederlands
  Group-Trips-and-Rooming-Lists_RU.xlsx   Русский
  Group-Trips-and-Rooming-Lists_FA.xlsx   فارسی
  Group-Trips-and-Rooming-Lists_UR.xlsx   اردو
  Group-Trips-and-Rooming-Lists_HI.xlsx   हिन्दी
  Group-Trips-and-Rooming-Lists_ZH.xlsx   中文
  Group-Trips-and-Rooming-Lists_ID.xlsx   Bahasa Indonesia
  Group-Trips-and-Rooming-Lists_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
