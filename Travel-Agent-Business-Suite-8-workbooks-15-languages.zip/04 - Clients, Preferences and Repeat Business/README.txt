Clients, Preferences and Repeat Business
Know every client and win their next trip

FILES
  Clients-Preferences-and-Repeat-Business_EN.xlsx   English
  Clients-Preferences-and-Repeat-Business_AR.xlsx   العربية
  Clients-Preferences-and-Repeat-Business_FR.xlsx   Français
  Clients-Preferences-and-Repeat-Business_ES.xlsx   Español
  Clients-Preferences-and-Repeat-Business_DE.xlsx   Deutsch
  Clients-Preferences-and-Repeat-Business_IT.xlsx   Italiano
  Clients-Preferences-and-Repeat-Business_PT.xlsx   Português
  Clients-Preferences-and-Repeat-Business_TR.xlsx   Türkçe
  Clients-Preferences-and-Repeat-Business_NL.xlsx   Nederlands
  Clients-Preferences-and-Repeat-Business_RU.xlsx   Русский
  Clients-Preferences-and-Repeat-Business_FA.xlsx   فارسی
  Clients-Preferences-and-Repeat-Business_UR.xlsx   اردو
  Clients-Preferences-and-Repeat-Business_HI.xlsx   हिन्दी
  Clients-Preferences-and-Repeat-Business_ZH.xlsx   中文
  Clients-Preferences-and-Repeat-Business_ID.xlsx   Bahasa Indonesia
  Clients-Preferences-and-Repeat-Business_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
