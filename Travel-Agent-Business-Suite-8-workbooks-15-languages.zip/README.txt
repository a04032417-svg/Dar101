Travel Agent Business Suite
Know what every trip earns – and never miss a final payment or a commission

WORKBOOKS
  01 - Enquiries, Quotes and Trip Pricing: Turn enquiries into booked trips at a margin that pays
  02 - Bookings, Deposits and Final Payments: Never miss a final payment deadline on a booked trip
  03 - Commissions and Host Splits: Know what every trip earns and chase every unpaid commission
  04 - Clients, Preferences and Repeat Business: Know every client and win their next trip
  05 - Itineraries, Documents and Requirements: Send every traveller off ready, with nothing missing
  06 - Group Trips and Rooming Lists: Place every traveller, room and payment of a group trip
  07 - Suppliers, Scorecards and Service Fees: Know which suppliers earn their place and which fees pay
  08 - Finance, Cash Flow, Taxes and Growth: Know your cash, your profit and your safe draw every month

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
