Finance, Cash Flow, Taxes and Growth
Know your cash, your profit and your safe draw every month

FILES
  Finance-Cash-Flow-Taxes-and-Growth_EN.xlsx   English
  Finance-Cash-Flow-Taxes-and-Growth_AR.xlsx   العربية
  Finance-Cash-Flow-Taxes-and-Growth_FR.xlsx   Français
  Finance-Cash-Flow-Taxes-and-Growth_ES.xlsx   Español
  Finance-Cash-Flow-Taxes-and-Growth_DE.xlsx   Deutsch
  Finance-Cash-Flow-Taxes-and-Growth_IT.xlsx   Italiano
  Finance-Cash-Flow-Taxes-and-Growth_PT.xlsx   Português
  Finance-Cash-Flow-Taxes-and-Growth_TR.xlsx   Türkçe
  Finance-Cash-Flow-Taxes-and-Growth_NL.xlsx   Nederlands
  Finance-Cash-Flow-Taxes-and-Growth_RU.xlsx   Русский
  Finance-Cash-Flow-Taxes-and-Growth_FA.xlsx   فارسی
  Finance-Cash-Flow-Taxes-and-Growth_UR.xlsx   اردو
  Finance-Cash-Flow-Taxes-and-Growth_HI.xlsx   हिन्दी
  Finance-Cash-Flow-Taxes-and-Growth_ZH.xlsx   中文
  Finance-Cash-Flow-Taxes-and-Growth_ID.xlsx   Bahasa Indonesia
  Finance-Cash-Flow-Taxes-and-Growth_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
