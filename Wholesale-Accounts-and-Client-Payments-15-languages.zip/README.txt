Wholesale Accounts and Client Payments
Wholesale accounts, invoices and client payments for home bakeries

FILES
  Wholesale-Accounts-and-Client-Payments_EN.xlsx   English
  Wholesale-Accounts-and-Client-Payments_AR.xlsx   العربية
  Wholesale-Accounts-and-Client-Payments_FR.xlsx   Français
  Wholesale-Accounts-and-Client-Payments_ES.xlsx   Español
  Wholesale-Accounts-and-Client-Payments_DE.xlsx   Deutsch
  Wholesale-Accounts-and-Client-Payments_IT.xlsx   Italiano
  Wholesale-Accounts-and-Client-Payments_PT.xlsx   Português
  Wholesale-Accounts-and-Client-Payments_TR.xlsx   Türkçe
  Wholesale-Accounts-and-Client-Payments_NL.xlsx   Nederlands
  Wholesale-Accounts-and-Client-Payments_RU.xlsx   Русский
  Wholesale-Accounts-and-Client-Payments_FA.xlsx   فارسی
  Wholesale-Accounts-and-Client-Payments_UR.xlsx   اردو
  Wholesale-Accounts-and-Client-Payments_HI.xlsx   हिन्दी
  Wholesale-Accounts-and-Client-Payments_ZH.xlsx   中文
  Wholesale-Accounts-and-Client-Payments_ID.xlsx   Bahasa Indonesia
  Wholesale-Accounts-and-Client-Payments_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
