Field Operations, Spraying and Harvest
Daily field work, spray records, intervals, loads and yield per field

FILES
  Field-Operations-Spraying-and-Harvest_EN.xlsx   English
  Field-Operations-Spraying-and-Harvest_AR.xlsx   العربية
  Field-Operations-Spraying-and-Harvest_FR.xlsx   Français
  Field-Operations-Spraying-and-Harvest_ES.xlsx   Español
  Field-Operations-Spraying-and-Harvest_DE.xlsx   Deutsch
  Field-Operations-Spraying-and-Harvest_IT.xlsx   Italiano
  Field-Operations-Spraying-and-Harvest_PT.xlsx   Português
  Field-Operations-Spraying-and-Harvest_TR.xlsx   Türkçe
  Field-Operations-Spraying-and-Harvest_NL.xlsx   Nederlands
  Field-Operations-Spraying-and-Harvest_RU.xlsx   Русский
  Field-Operations-Spraying-and-Harvest_FA.xlsx   فارسی
  Field-Operations-Spraying-and-Harvest_UR.xlsx   اردو
  Field-Operations-Spraying-and-Harvest_HI.xlsx   हिन्दी
  Field-Operations-Spraying-and-Harvest_ZH.xlsx   中文
  Field-Operations-Spraying-and-Harvest_ID.xlsx   Bahasa Indonesia
  Field-Operations-Spraying-and-Harvest_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
