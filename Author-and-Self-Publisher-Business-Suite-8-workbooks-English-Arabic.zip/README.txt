Author and Self-Publisher Business Suite
See which books pay back, which ads to stop and when store royalties arrive

WORKBOOKS
  01 - Catalogue, Series Plan and Releases: Find a clear release date and the day to start your next draft
  02 - Production Costs and Break-Even: Decide on audio, large print or a translation before you pay for it
  03 - Sales and Royalties Ledger: Know when royalties really arrive and catch a missing sale early
  04 - Ads and Price Promotions: Know the most an ad can spend per sale, and test a price change first
  05 - Readers, Newsletter and Launches: See if a launch is ready, which steps are late and what each swap brings
  06 - Series, Title and Pen-Name Performance: Find where readers drop and how many more books reach your target income
  07 - Direct Sales, Stock, Events and Rights: Set a minimum print price, reorder in time and know which events to repeat
  08 - Cash, Tax, Expenses and Author Shares: See cash 12 months ahead in three cases and what each author is owed

Each folder holds the workbook in English and in Arabic, and a copy of each full of sample data. / كل مجلد فيه ملف العمل بالإنجليزية وبالعربية، ونسخة من كل منهما مملوءة ببيانات تجريبية.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
