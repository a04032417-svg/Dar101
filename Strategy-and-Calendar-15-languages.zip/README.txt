Strategy and Calendar
Content calendar and strategy for every brand you manage in one file

FILES
  Strategy-and-Calendar_EN.xlsx   English
  Strategy-and-Calendar_AR.xlsx   العربية
  Strategy-and-Calendar_FR.xlsx   Français
  Strategy-and-Calendar_ES.xlsx   Español
  Strategy-and-Calendar_DE.xlsx   Deutsch
  Strategy-and-Calendar_IT.xlsx   Italiano
  Strategy-and-Calendar_PT.xlsx   Português
  Strategy-and-Calendar_TR.xlsx   Türkçe
  Strategy-and-Calendar_NL.xlsx   Nederlands
  Strategy-and-Calendar_RU.xlsx   Русский
  Strategy-and-Calendar_FA.xlsx   فارسی
  Strategy-and-Calendar_UR.xlsx   اردو
  Strategy-and-Calendar_HI.xlsx   हिन्दी
  Strategy-and-Calendar_ZH.xlsx   中文
  Strategy-and-Calendar_ID.xlsx   Bahasa Indonesia
  Strategy-and-Calendar_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
