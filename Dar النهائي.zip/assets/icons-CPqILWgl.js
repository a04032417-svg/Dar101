import{c as a,u as U,a as E,a3 as F,I,R as n,j as e,a4 as C,a5 as O,X as R,a6 as Z,z as B,a0 as D,a7 as G,V as u,p as z,e as L,a8 as W,U as _,a9 as X,W as Y,s as $,a2 as J,Z as K,D as Q,N as ee,C as ae,Y as te,d as H}from"./index-Dwd8FNoY.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const He=a("Activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=a("Bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=a("Braces",[["path",{d:"M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5c0 1.1.9 2 2 2h1",key:"ezmyqa"}],["path",{d:"M16 21h1a2 2 0 0 0 2-2v-5c0-1.1.9-2 2-2a2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1",key:"e1hn23"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=a("ChartColumn",[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=a("CircleCheck",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ne=a("CirclePlus",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}],["path",{d:"M12 8v8",key:"napkw2"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qe=a("CircleX",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ie=a("Clock4",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ve=a("Coins",[["circle",{cx:"8",cy:"8",r:"6",key:"3yglwk"}],["path",{d:"M18.09 10.37A6 6 0 1 1 10.34 18",key:"t5s6rm"}],["path",{d:"M7 6h1v4",key:"1obek4"}],["path",{d:"m16.71 13.88.7.71-2.82 2.82",key:"1rbuyh"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pe=a("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const he=a("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=a("FolderOpen",[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",key:"usdka0"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oe=a("Gem",[["path",{d:"M6 3h12l4 6-10 13L2 9Z",key:"1pcd5k"}],["path",{d:"M11 3 8 9l4 13 4-13-3-6",key:"1fcu3u"}],["path",{d:"M2 9h20",key:"16fsjt"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ye=a("Headset",[["path",{d:"M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z",key:"12oyoe"}],["path",{d:"M21 16v2a4 4 0 0 1-4 4h-5",key:"1x7m43"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ae=a("Layers",[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Te=a("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xe=a("LifeBuoy",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m4.93 4.93 4.24 4.24",key:"1ymg45"}],["path",{d:"m14.83 9.17 4.24-4.24",key:"1cb5xl"}],["path",{d:"m14.83 14.83 4.24 4.24",key:"q42g0n"}],["path",{d:"m9.17 14.83-4.24 4.24",key:"bqpfvv"}],["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ke=a("ListChecks",[["path",{d:"m3 17 2 2 4-4",key:"1jhpwq"}],["path",{d:"m3 7 2 2 4-4",key:"1obspn"}],["path",{d:"M13 6h8",key:"15sg57"}],["path",{d:"M13 12h8",key:"h98zly"}],["path",{d:"M13 18h8",key:"oe0vm4"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=a("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pe=a("Megaphone",[["path",{d:"m3 11 18-5v12L3 14v-3z",key:"n962bs"}],["path",{d:"M11.6 16.8a3 3 0 1 1-5.8-1.6",key:"1yl0tm"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const me=a("MessagesSquare",[["path",{d:"M14 9a2 2 0 0 1-2 2H6l-4 4V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2z",key:"p1xzt8"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1",key:"1cx29u"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ue=a("Network",[["rect",{x:"16",y:"16",width:"6",height:"6",rx:"1",key:"4q2zg0"}],["rect",{x:"2",y:"16",width:"6",height:"6",rx:"1",key:"8cvhb9"}],["rect",{x:"9",y:"2",width:"6",height:"6",rx:"1",key:"1egb70"}],["path",{d:"M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3",key:"1jsf9p"}],["path",{d:"M12 12V8",key:"2874zd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ue=a("Pencil",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ee=a("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const be=a("Rocket",[["path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z",key:"m3kijz"}],["path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z",key:"1fmvmk"}],["path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0",key:"1f8sc4"}],["path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",key:"qeys4"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Fe=a("Ruler",[["path",{d:"M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z",key:"icamh8"}],["path",{d:"m14.5 12.5 2-2",key:"inckbg"}],["path",{d:"m11.5 9.5 2-2",key:"fmmyf7"}],["path",{d:"m8.5 6.5 2-2",key:"vc6u1g"}],["path",{d:"m17.5 15.5 2-2",key:"wo5hmg"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ge=a("Scale",[["path",{d:"m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"7g6ntu"}],["path",{d:"m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"ijws7r"}],["path",{d:"M7 21h10",key:"1b0cd5"}],["path",{d:"M12 3v18",key:"108xh3"}],["path",{d:"M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2",key:"3gwbw2"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ie=a("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fe=a("Settings2",[["path",{d:"M20 7h-9",key:"3s1dr2"}],["path",{d:"M14 17H5",key:"gfn3mx"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ve=a("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const we=a("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Oe=a("SpellCheck",[["path",{d:"m6 16 6-12 6 12",key:"1b4byz"}],["path",{d:"M8 12h8",key:"1wcyev"}],["path",{d:"m16 20 2 2 4-4",key:"13tcca"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const je=a("Star",[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Me=a("Target",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ne=a("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ce=a("UserPlus",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"19",x2:"19",y1:"8",y2:"14",key:"1bvyxn"}],["line",{x1:"22",x2:"16",y1:"11",y2:"11",key:"1shjgl"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ze=a("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Se=a("Video",[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Re=a("WandSparkles",[["path",{d:"m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72",key:"ul74o6"}],["path",{d:"m14 7 3 3",key:"1r5n42"}],["path",{d:"M5 6v4",key:"ilb8ba"}],["path",{d:"M19 14v4",key:"blhpug"}],["path",{d:"M10 2v2",key:"7u0qdc"}],["path",{d:"M7 8H3",key:"zfb6yr"}],["path",{d:"M21 16h-4",key:"1cnmox"}],["path",{d:"M11 3H9",key:"1obp7u"}]]);function Ze({nav:s,active:l,onNav:r,title:p,actions:x,children:k,mode:i}){const{user:t,logout:m}=U(),{c:h,dir:d,lang:c}=E(),{theme:y,toggle:V}=F(),f=I(),[b,g]=n.useState(!1),[v,w]=n.useState(!1),j=s.find(o=>o.key===l),P=i==="client"?"/app":"/dev",M=async()=>{await m(),f("/")},N=e.jsxs("aside",{className:"h-full flex flex-col",children:[e.jsx("div",{className:"px-4 py-5",children:e.jsxs(C,{to:"/",className:"flex items-center gap-2",children:[e.jsx(O,{className:"w-9 h-9 rounded-xl"}),e.jsxs("div",{children:[e.jsx("div",{className:"font-black leading-none",children:h("meta").name}),e.jsx("div",{className:"text-[0.65rem] text-white/40 mt-1",children:i==="client"?h("dashboards").eyebrow||"لوحة العميل":h("developerSite").name||"مطوّر المنصة"})]})]})}),e.jsx("nav",{className:"nav-side flex-1 overflow-y-auto px-3 pb-4 space-y-1",children:s.map(o=>{const A=l===o.key||o.key==="dashboard"&&l==="";return e.jsxs("a",{href:P+"/"+o.key,className:A?"active":"",onClick:T=>{T.preventDefault(),r(o.key),g(!1)},children:[e.jsx("span",{className:"opacity-80",children:o.icon}),o.label]},o.key)})}),e.jsxs("div",{className:"p-4 border-t border-white/8",children:[e.jsxs("div",{className:"rounded-2xl bg-white/[0.03] border border-white/10 p-3 mb-3 text-[0.7rem] text-white/40 leading-relaxed",children:[e.jsx(xe,{className:"w-3.5 h-3.5 inline-block ml-1 text-cyan-300"}),i==="client"?h("dashboards").tag:h("developerSite").intro]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"w-9 h-9 rounded-full bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center font-black text-sm",children:((t==null?void 0:t.name)||"؟").charAt(0)}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("div",{className:"text-sm font-bold truncate",children:t==null?void 0:t.name}),e.jsx("div",{className:"text-[0.65rem] text-white/40 truncate",children:(t==null?void 0:t.email)||(t==null?void 0:t.role)})]}),e.jsx("button",{className:"p-2 rounded-lg hover:bg-white/10 text-white/50",onClick:M,title:"خروج",children:e.jsx(S,{className:"w-4 h-4"})})]})]})]});return e.jsxs("div",{className:"min-h-screen bg-black text-white flex",dir:d,children:[e.jsx("div",{className:"hidden lg:block w-[248px] shrink-0 border-e border-white/8 bg-[#0e0e11] fixed inset-y-0 z-40",children:N}),b&&e.jsxs("div",{className:"lg:hidden fixed inset-0 z-50 flex",children:[e.jsx("div",{className:"absolute inset-0 bg-black/70",onClick:()=>g(!1)}),e.jsx("aside",{className:"relative w-64 bg-[#0e0e11] border-e border-white/8 h-full overflow-y-auto",children:N})]}),e.jsxs("div",{className:"flex-1 lg:ps-[248px] min-w-0",children:[e.jsx("header",{className:"sticky top-0 z-30 backdrop-blur-xl bg-black/60 border-b border-white/8",children:e.jsxs("div",{className:"h-14 px-4 sm:px-6 flex items-center gap-3",children:[e.jsx("button",{className:"lg:hidden p-2 -me-1 rounded-lg hover:bg-white/10 text-white/70",onClick:()=>g(!b),children:b?e.jsx(R,{className:"w-5 h-5"}):e.jsx(Z,{className:"w-5 h-5"})}),e.jsx("div",{className:"flex-1 min-w-0",children:e.jsx("h1",{className:"font-black truncate",children:j?j.label:p})}),e.jsxs("div",{className:"hidden sm:flex items-center gap-2",children:[e.jsx("button",{className:"w-9 h-9 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 text-white/70 flex items-center justify-center transition-all",onClick:V,title:y==="dark"?c==="ar"?"الوضع الفاتح":"Light mode":c==="ar"?"الوضع الداكن":"Dark mode","aria-label":y==="dark"?c==="ar"?"الوضع الفاتح":"Light mode":c==="ar"?"الوضع الداكن":"Dark mode",children:y==="dark"?e.jsx(B,{className:"w-4 h-4"}):e.jsx(D,{className:"w-4 h-4"})}),e.jsx(G,{compact:!0})]}),x,i==="dev"&&e.jsxs("div",{className:"hidden md:flex items-center gap-2",children:[e.jsxs("a",{href:"/preview/site",target:"_blank",rel:"noreferrer",className:"btn btn-ghost btn-sm",children:[e.jsx(u,{className:"w-3.5 h-3.5"})," ",c==="ar"?"افتح الموقع":"Open site"]}),e.jsxs("a",{href:"/preview/portal/1",target:"_blank",rel:"noreferrer",className:"btn btn-brand btn-sm",children:[e.jsx(z,{className:"w-3.5 h-3.5"})," ",c==="ar"?"واجهة العميل":"Client UI"]})]}),e.jsxs("div",{className:"relative",children:[e.jsx("button",{className:"w-9 h-9 rounded-full bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center font-black text-sm hover:ring-2 ring-cyan-300/40 transition-all",onClick:()=>w(!v),children:((t==null?void 0:t.name)||"؟").charAt(0)}),v&&e.jsxs("div",{className:"absolute end-0 top-11 w-56 rounded-2xl border border-white/10 bg-[#151519] shadow-2xl p-2 text-sm",children:[e.jsxs("div",{className:"px-3 py-2 border-b border-white/8 mb-1",children:[e.jsx("div",{className:"font-bold truncate",children:t==null?void 0:t.name}),e.jsx("div",{className:"text-xs text-white/40 truncate",children:(t==null?void 0:t.email)||(t==null?void 0:t.phone)}),e.jsx("div",{className:"badge badge-cyan mt-2",children:i==="client"?(t==null?void 0:t.officeRole)||"عضو مكتب":"مطوّر المنصة"})]}),i==="client"&&e.jsxs(C,{to:"/",className:"flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/5 text-white/70",children:[e.jsx(u,{className:"w-4 h-4"})," ",h("meta").name," · الموقع"]}),i==="dev"&&e.jsxs(e.Fragment,{children:[e.jsxs("a",{href:"/preview/site",target:"_blank",rel:"noreferrer",className:"flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/5 text-white/70",children:[e.jsx(u,{className:"w-4 h-4"})," ",c==="ar"?"افتح الموقع (معاينة)":"Open site (preview)"]}),e.jsxs("a",{href:"/preview/portal/1",target:"_blank",rel:"noreferrer",className:"flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/5 text-white/70",children:[e.jsx(z,{className:"w-4 h-4"})," ",c==="ar"?"واجهة العميل (معاينة)":"Client UI (preview)"]}),e.jsxs("button",{onClick:()=>{w(!1),f("/dev/content")},className:"w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/5 text-white/70",children:[e.jsx(fe,{className:"w-4 h-4"})," ",c==="ar"?"تحرير المحتوى":"Edit content"]})]}),e.jsxs("button",{onClick:M,className:"w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-red-500/10 text-red-300",children:[e.jsx(S,{className:"w-4 h-4"})," خروج"]})]})]})]})}),e.jsx("main",{className:"p-4 sm:p-6 max-w-[1280px] mx-auto",children:k})]})]})}function Be(s,l){const[r,p]=n.useState([]),[x,k]=n.useState(!0),[i,t]=n.useState(""),[m,h]=n.useState(0),d=n.useCallback(()=>h(c=>c+1),[]);return n.useEffect(()=>{let c=!0;return k(!0),L(s).then(y=>{c&&(p(y[l]||[]),t(""))}).catch(y=>c&&t(y.message)).finally(()=>c&&k(!1)),()=>{c=!1}},[s,m,l]),{items:r,loading:x,err:i,reload:d}}function De(s){const[l,r]=n.useState(null),[p,x]=n.useState(!0),[k,i]=n.useState(""),[t,m]=n.useState(0),h=n.useCallback(()=>m(d=>d+1),[]);return n.useEffect(()=>{let d=!0;return x(!0),L(s).then(c=>{d&&(r(c),i(""))}).catch(c=>d&&i(c.message)).finally(()=>d&&x(!1)),()=>{d=!1}},[s,t]),{data:l,loading:p,err:k,reload:h}}function Ge(){const[s,l]=n.useState(null);return n.useEffect(()=>{if(!s)return;const r=setTimeout(()=>l(null),2600);return()=>clearTimeout(r)},[s]),{msg:s,setMsg:l,ok:r=>l({text:r,tone:"ok"}),fail:r=>l({text:r,tone:"err"})}}function We({msg:s}){if(!s)return null;const l=s.tone==="ok"?"border-emerald-400/40 bg-emerald-500/10 text-emerald-200":"border-red-400/40 bg-red-500/10 text-red-200";return e.jsx("div",{className:`fixed bottom-5 left-1/2 -translate-x-1/2 z-[70] rounded-xl border px-5 py-3 text-sm font-bold shadow-2xl backdrop-blur-xl ${l}`,children:s.text})}function _e({title:s,sub:l,actions:r}){return e.jsxs("div",{className:"flex flex-wrap items-end justify-between gap-3 mb-5",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-xl font-black",children:s}),l&&e.jsx("p",{className:"text-white/45 text-sm mt-1",children:l})]}),r&&e.jsx("div",{className:"flex items-center gap-2",children:r})]})}const q={Sparkles:H,Megaphone:pe,Users:ze,UserPlus:Ce,MessageCircle:te,MessagesSquare:me,CalendarDays:ae,Target:Me,BarChart3:ce,Scale:ge,Clock4:ie,FileText:he,FolderOpen:de,Braces:le,MapPin:ee,Globe:u,TrendingUp:Ne,Star:je,Bot:se,Rocket:be,PlusCircle:ne,Headset:ye,CreditCard:Q,Zap:K,Shield:we,Mail:J,Phone:$,Video:Se,Wallet:Y,Network:ue,Workflow:X,Puzzle:_,ListChecks:ke,CheckCircle2:re,Settings:ve,LayoutGrid:W,Gem:oe};function Xe({name:s,className:l}){const r=s&&q[s]||H;return e.jsx(r,{className:l||"w-4 h-4"})}const Ye=Object.keys(q);export{He as A,se as B,Pe as C,We as F,Ye as I,Ae as L,pe as M,_e as P,Fe as R,ge as S,Ne as T,ze as U,Se as V,Re as W,Ge as a,Ee as b,me as c,Be as d,Ce as e,Ue as f,Ve as g,he as h,Me as i,ie as j,Oe as k,re as l,qe as m,Ie as n,Xe as o,je as p,Ze as q,Te as r,ce as s,de as t,De as u,ve as v};
