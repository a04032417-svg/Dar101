Personal Training Suite
Run a personal training business from four connected Excel workbooks

WORKBOOKS
  01 - Clients and Memberships: Clients, packages, sessions left, payments, renewals and leads in one file
  02 - Programmes and Progress: Exercise library, programmes, workout log, records and goals in one file
  03 - Money and Coaches: Income, invoices, coach pay, margins and cash forecast in one file
  04 - Studio and Schedule: Timetable, slot fill, rooms, equipment and safety log in one file

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
