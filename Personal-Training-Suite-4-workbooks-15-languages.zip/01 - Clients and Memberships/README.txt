Clients and Memberships
Clients, packages, sessions left, payments, renewals and leads in one file

FILES
  Clients-and-Memberships_EN.xlsx   English
  Clients-and-Memberships_AR.xlsx   العربية
  Clients-and-Memberships_FR.xlsx   Français
  Clients-and-Memberships_ES.xlsx   Español
  Clients-and-Memberships_DE.xlsx   Deutsch
  Clients-and-Memberships_IT.xlsx   Italiano
  Clients-and-Memberships_PT.xlsx   Português
  Clients-and-Memberships_TR.xlsx   Türkçe
  Clients-and-Memberships_NL.xlsx   Nederlands
  Clients-and-Memberships_RU.xlsx   Русский
  Clients-and-Memberships_FA.xlsx   فارسی
  Clients-and-Memberships_UR.xlsx   اردو
  Clients-and-Memberships_HI.xlsx   हिन्दी
  Clients-and-Memberships_ZH.xlsx   中文
  Clients-and-Memberships_ID.xlsx   Bahasa Indonesia
  Clients-and-Memberships_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
