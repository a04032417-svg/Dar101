Timelines and Day-of Coordination
Run-of-show, milestones, vendor arrivals and day-of plans for event planners

FILES
  Timelines-and-Day-of-Coordination_EN.xlsx   English
  Timelines-and-Day-of-Coordination_AR.xlsx   العربية
  Timelines-and-Day-of-Coordination_FR.xlsx   Français
  Timelines-and-Day-of-Coordination_ES.xlsx   Español
  Timelines-and-Day-of-Coordination_DE.xlsx   Deutsch
  Timelines-and-Day-of-Coordination_IT.xlsx   Italiano
  Timelines-and-Day-of-Coordination_PT.xlsx   Português
  Timelines-and-Day-of-Coordination_TR.xlsx   Türkçe
  Timelines-and-Day-of-Coordination_NL.xlsx   Nederlands
  Timelines-and-Day-of-Coordination_RU.xlsx   Русский
  Timelines-and-Day-of-Coordination_FA.xlsx   فارسی
  Timelines-and-Day-of-Coordination_UR.xlsx   اردو
  Timelines-and-Day-of-Coordination_HI.xlsx   हिन्दी
  Timelines-and-Day-of-Coordination_ZH.xlsx   中文
  Timelines-and-Day-of-Coordination_ID.xlsx   Bahasa Indonesia
  Timelines-and-Day-of-Coordination_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
