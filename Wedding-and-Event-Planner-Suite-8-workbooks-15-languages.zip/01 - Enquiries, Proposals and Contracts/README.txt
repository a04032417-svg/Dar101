Enquiries, Proposals and Contracts
Turn every enquiry into a signed contract and a secured date

FILES
  Enquiries-Proposals-and-Contracts_EN.xlsx   English
  Enquiries-Proposals-and-Contracts_AR.xlsx   العربية
  Enquiries-Proposals-and-Contracts_FR.xlsx   Français
  Enquiries-Proposals-and-Contracts_ES.xlsx   Español
  Enquiries-Proposals-and-Contracts_DE.xlsx   Deutsch
  Enquiries-Proposals-and-Contracts_IT.xlsx   Italiano
  Enquiries-Proposals-and-Contracts_PT.xlsx   Português
  Enquiries-Proposals-and-Contracts_TR.xlsx   Türkçe
  Enquiries-Proposals-and-Contracts_NL.xlsx   Nederlands
  Enquiries-Proposals-and-Contracts_RU.xlsx   Русский
  Enquiries-Proposals-and-Contracts_FA.xlsx   فارسی
  Enquiries-Proposals-and-Contracts_UR.xlsx   اردو
  Enquiries-Proposals-and-Contracts_HI.xlsx   हिन्दी
  Enquiries-Proposals-and-Contracts_ZH.xlsx   中文
  Enquiries-Proposals-and-Contracts_ID.xlsx   Bahasa Indonesia
  Enquiries-Proposals-and-Contracts_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
