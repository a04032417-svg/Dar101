Wedding and Event Planner Suite
Win more events, collect every payment and see your real profit on each one

WORKBOOKS
  01 - Enquiries, Proposals and Contracts: Turn every enquiry into a signed contract and a secured date
  02 - Clients, Payments and Invoicing: Invoices, deposits and late payers for a wedding and event planning business
  03 - Event Budget and Costing by Guests: Event budgets by guest count, quotes, reserve and margin for event planners
  04 - Vendors, Bookings and Payments: Vendor bookings, payments, quotes and holds for event planners
  05 - Guests, RSVPs and Seating: Guest lists, RSVPs, seating, meals and check-in for event planners
  06 - Timelines and Day-of Coordination: Run-of-show, milestones, vendor arrivals and day-of plans for event planners
  07 - Team, Tasks and Capacity: Team tasks, hours, capacity, labour cost and hiring for event planners
  08 - Business Finance and Growth: Event profit, cash forecast, marketing return and break-even for event planners

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
