Vendors, Bookings and Payments
Vendor bookings, payments, quotes and holds for event planners

FILES
  Vendors-Bookings-and-Payments_EN.xlsx   English
  Vendors-Bookings-and-Payments_AR.xlsx   العربية
  Vendors-Bookings-and-Payments_FR.xlsx   Français
  Vendors-Bookings-and-Payments_ES.xlsx   Español
  Vendors-Bookings-and-Payments_DE.xlsx   Deutsch
  Vendors-Bookings-and-Payments_IT.xlsx   Italiano
  Vendors-Bookings-and-Payments_PT.xlsx   Português
  Vendors-Bookings-and-Payments_TR.xlsx   Türkçe
  Vendors-Bookings-and-Payments_NL.xlsx   Nederlands
  Vendors-Bookings-and-Payments_RU.xlsx   Русский
  Vendors-Bookings-and-Payments_FA.xlsx   فارسی
  Vendors-Bookings-and-Payments_UR.xlsx   اردو
  Vendors-Bookings-and-Payments_HI.xlsx   हिन्दी
  Vendors-Bookings-and-Payments_ZH.xlsx   中文
  Vendors-Bookings-and-Payments_ID.xlsx   Bahasa Indonesia
  Vendors-Bookings-and-Payments_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
