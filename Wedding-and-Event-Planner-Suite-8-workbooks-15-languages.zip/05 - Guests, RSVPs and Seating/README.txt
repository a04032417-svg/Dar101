Guests, RSVPs and Seating
Guest lists, RSVPs, seating, meals and check-in for event planners

FILES
  Guests-RSVPs-and-Seating_EN.xlsx   English
  Guests-RSVPs-and-Seating_AR.xlsx   العربية
  Guests-RSVPs-and-Seating_FR.xlsx   Français
  Guests-RSVPs-and-Seating_ES.xlsx   Español
  Guests-RSVPs-and-Seating_DE.xlsx   Deutsch
  Guests-RSVPs-and-Seating_IT.xlsx   Italiano
  Guests-RSVPs-and-Seating_PT.xlsx   Português
  Guests-RSVPs-and-Seating_TR.xlsx   Türkçe
  Guests-RSVPs-and-Seating_NL.xlsx   Nederlands
  Guests-RSVPs-and-Seating_RU.xlsx   Русский
  Guests-RSVPs-and-Seating_FA.xlsx   فارسی
  Guests-RSVPs-and-Seating_UR.xlsx   اردو
  Guests-RSVPs-and-Seating_HI.xlsx   हिन्दी
  Guests-RSVPs-and-Seating_ZH.xlsx   中文
  Guests-RSVPs-and-Seating_ID.xlsx   Bahasa Indonesia
  Guests-RSVPs-and-Seating_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
