Clients, Payments and Invoicing
Invoices, deposits and late payers for a wedding and event planning business

FILES
  Clients-Payments-and-Invoicing_EN.xlsx   English
  Clients-Payments-and-Invoicing_AR.xlsx   العربية
  Clients-Payments-and-Invoicing_FR.xlsx   Français
  Clients-Payments-and-Invoicing_ES.xlsx   Español
  Clients-Payments-and-Invoicing_DE.xlsx   Deutsch
  Clients-Payments-and-Invoicing_IT.xlsx   Italiano
  Clients-Payments-and-Invoicing_PT.xlsx   Português
  Clients-Payments-and-Invoicing_TR.xlsx   Türkçe
  Clients-Payments-and-Invoicing_NL.xlsx   Nederlands
  Clients-Payments-and-Invoicing_RU.xlsx   Русский
  Clients-Payments-and-Invoicing_FA.xlsx   فارسی
  Clients-Payments-and-Invoicing_UR.xlsx   اردو
  Clients-Payments-and-Invoicing_HI.xlsx   हिन्दी
  Clients-Payments-and-Invoicing_ZH.xlsx   中文
  Clients-Payments-and-Invoicing_ID.xlsx   Bahasa Indonesia
  Clients-Payments-and-Invoicing_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
