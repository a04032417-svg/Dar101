Event Budget and Costing by Guests
Event budgets by guest count, quotes, reserve and margin for event planners

FILES
  Event-Budget-and-Costing-by-Guests_EN.xlsx   English
  Event-Budget-and-Costing-by-Guests_AR.xlsx   العربية
  Event-Budget-and-Costing-by-Guests_FR.xlsx   Français
  Event-Budget-and-Costing-by-Guests_ES.xlsx   Español
  Event-Budget-and-Costing-by-Guests_DE.xlsx   Deutsch
  Event-Budget-and-Costing-by-Guests_IT.xlsx   Italiano
  Event-Budget-and-Costing-by-Guests_PT.xlsx   Português
  Event-Budget-and-Costing-by-Guests_TR.xlsx   Türkçe
  Event-Budget-and-Costing-by-Guests_NL.xlsx   Nederlands
  Event-Budget-and-Costing-by-Guests_RU.xlsx   Русский
  Event-Budget-and-Costing-by-Guests_FA.xlsx   فارسی
  Event-Budget-and-Costing-by-Guests_UR.xlsx   اردو
  Event-Budget-and-Costing-by-Guests_HI.xlsx   हिन्दी
  Event-Budget-and-Costing-by-Guests_ZH.xlsx   中文
  Event-Budget-and-Costing-by-Guests_ID.xlsx   Bahasa Indonesia
  Event-Budget-and-Costing-by-Guests_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
