Team, Tasks and Capacity
Team tasks, hours, capacity, labour cost and hiring for event planners

FILES
  Team-Tasks-and-Capacity_EN.xlsx   English
  Team-Tasks-and-Capacity_AR.xlsx   العربية
  Team-Tasks-and-Capacity_FR.xlsx   Français
  Team-Tasks-and-Capacity_ES.xlsx   Español
  Team-Tasks-and-Capacity_DE.xlsx   Deutsch
  Team-Tasks-and-Capacity_IT.xlsx   Italiano
  Team-Tasks-and-Capacity_PT.xlsx   Português
  Team-Tasks-and-Capacity_TR.xlsx   Türkçe
  Team-Tasks-and-Capacity_NL.xlsx   Nederlands
  Team-Tasks-and-Capacity_RU.xlsx   Русский
  Team-Tasks-and-Capacity_FA.xlsx   فارسی
  Team-Tasks-and-Capacity_UR.xlsx   اردو
  Team-Tasks-and-Capacity_HI.xlsx   हिन्दी
  Team-Tasks-and-Capacity_ZH.xlsx   中文
  Team-Tasks-and-Capacity_ID.xlsx   Bahasa Indonesia
  Team-Tasks-and-Capacity_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
