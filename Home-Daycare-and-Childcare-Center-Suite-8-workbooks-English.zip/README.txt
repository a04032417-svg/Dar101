Home Daycare and Childcare Center Suite
Fill every place, bill every family and see your cash 13 weeks ahead

WORKBOOKS
  01 - Enquiries, Tours and Waitlist: Rank waiting families by the tuition they bring and fill each free place
  02 - Rooms, Places and Attendance: See free places by room and weekday, and billed hours against hours present
  03 - Staff, Rota and Ratios: Spot every short room-hour against your ratio and send relief where it helps
  04 - Tuition, Fees and Invoices: Send the right invoice to every family, with fees and discounts worked out
  05 - Payments, Balances and Cash: Chase the right balance first and see your cash 13 weeks ahead
  06 - Meals, Health and Safety Records: Cost every menu day and keep record status, incidents and drills up to date
  07 - Families, Programs and Camps: Call the family waiting longest and run only the camp weeks that break even
  08 - Business Health and Planning: Find the room that loses money and the owner draw you can afford

Each folder holds the workbook and a copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
