Nonprofit Organization Suite
Know who lapsed, which report is due and how many months of cash you have

WORKBOOKS
  01 - Donor Book and Gift Log: Thank every gift on time, tie out your banking and chase late pledges
  02 - Donor Growth and Major Gifts: Know who lapsed, who to win back and who to ask for more
  03 - Grants and Restricted Funds: Know which funder report to write first and which fund is short
  04 - Events and Campaigns: See the net of every event and where each campaign will finish
  05 - Programs and People Served: Count people served, cost per participant and results for every funder report
  06 - Volunteers and Members: See which shifts are short, who to ask first and which members to renew
  07 - Board and Governance: Know whose term ends, whether you have a quorum and what is due next
  08 - Budget, Cash and Annual Report: See your lowest cash month, months of reserve and what you can afford

Each folder holds the workbook in English and in Arabic, and a copy of each full of sample data. / كل مجلد فيه ملف العمل بالإنجليزية وبالعربية، ونسخة من كل منهما مملوءة ببيانات تجريبية.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
