Budget, Costs and Procurement
Control project budget, forecast, purchasing and client billing

FILES
  Budget-Costs-and-Procurement_EN.xlsx   English
  Budget-Costs-and-Procurement_AR.xlsx   العربية
  Budget-Costs-and-Procurement_FR.xlsx   Français
  Budget-Costs-and-Procurement_ES.xlsx   Español
  Budget-Costs-and-Procurement_DE.xlsx   Deutsch
  Budget-Costs-and-Procurement_IT.xlsx   Italiano
  Budget-Costs-and-Procurement_PT.xlsx   Português
  Budget-Costs-and-Procurement_TR.xlsx   Türkçe
  Budget-Costs-and-Procurement_NL.xlsx   Nederlands
  Budget-Costs-and-Procurement_RU.xlsx   Русский
  Budget-Costs-and-Procurement_FA.xlsx   فارسی
  Budget-Costs-and-Procurement_UR.xlsx   اردو
  Budget-Costs-and-Procurement_HI.xlsx   हिन्दी
  Budget-Costs-and-Procurement_ZH.xlsx   中文
  Budget-Costs-and-Procurement_ID.xlsx   Bahasa Indonesia
  Budget-Costs-and-Procurement_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
