Therapy Private Practice Suite
Find the service that loses money and see cash trouble 13 weeks ahead

WORKBOOKS
  01 - Intake, Screening and Waitlist: Reply to every enquiry fast and know who to offer a place first
  02 - Scheduling, Caseload and Rooms: Keep every clinician within the weekly cap and every slot filled
  03 - Client Fees, Accounts and Packages: Know who owes what and chase the right clients first
  04 - Third-party Payer Billing and Claims: Track every claim to payment and fix denials before they go cold
  05 - Clinician Pay and Productivity: Check every contractor statement and see each clinician's margin
  06 - Clinical Admin and Renewals: Never miss a late note, a supervision hour or a renewal date
  07 - Referrals, Marketing and Groups: See which sources bring clients who stay and fill every group
  08 - Practice Profit, Cash Flow and Growth: See profit by service and cash 13 weeks ahead, then plan growth

Each folder holds the workbook and a copy full of sample data.
Standard .xlsx files for Microsoft Excel, Google Sheets and LibreOffice Calc. No macros.
Google Sheets: open Google-Sheets-copy-links.txt and press "Make a copy" on each link.
Personal use licence for one business.
