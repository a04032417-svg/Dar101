Social Media Management Suite
Run a social media management business from eight connected Excel workbooks

WORKBOOKS
  01 - Clients, Contracts and Onboarding: Clients, contracts and onboarding for your social media business
  02 - Strategy and Calendar: Content calendar and strategy for every brand you manage in one file
  03 - Production and Approvals: Production pipeline and client approvals for every brand you manage
  04 - Publishing and Community: Publishing log and community inbox for every brand you manage in one file
  05 - Analytics and Reporting: Results and reports for every brand you manage in one file
  06 - Paid Ads and Budgets: Ad spend, budgets and results for every client you run ads for
  07 - Creators and Partnerships: Run creator campaigns, contracts and payments for every brand you manage
  08 - Team, Time and Finance: Timesheet, invoices, profit and cash for your agency

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
