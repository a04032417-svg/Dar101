Publishing and Community
Publishing log and community inbox for every brand you manage in one file

FILES
  Publishing-and-Community_EN.xlsx   English
  Publishing-and-Community_AR.xlsx   العربية
  Publishing-and-Community_FR.xlsx   Français
  Publishing-and-Community_ES.xlsx   Español
  Publishing-and-Community_DE.xlsx   Deutsch
  Publishing-and-Community_IT.xlsx   Italiano
  Publishing-and-Community_PT.xlsx   Português
  Publishing-and-Community_TR.xlsx   Türkçe
  Publishing-and-Community_NL.xlsx   Nederlands
  Publishing-and-Community_RU.xlsx   Русский
  Publishing-and-Community_FA.xlsx   فارسی
  Publishing-and-Community_UR.xlsx   اردو
  Publishing-and-Community_HI.xlsx   हिन्दी
  Publishing-and-Community_ZH.xlsx   中文
  Publishing-and-Community_ID.xlsx   Bahasa Indonesia
  Publishing-and-Community_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
