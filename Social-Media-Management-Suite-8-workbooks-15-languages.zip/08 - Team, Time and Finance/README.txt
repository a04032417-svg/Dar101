Team, Time and Finance
Timesheet, invoices, profit and cash for your agency

FILES
  Team-Time-and-Finance_EN.xlsx   English
  Team-Time-and-Finance_AR.xlsx   العربية
  Team-Time-and-Finance_FR.xlsx   Français
  Team-Time-and-Finance_ES.xlsx   Español
  Team-Time-and-Finance_DE.xlsx   Deutsch
  Team-Time-and-Finance_IT.xlsx   Italiano
  Team-Time-and-Finance_PT.xlsx   Português
  Team-Time-and-Finance_TR.xlsx   Türkçe
  Team-Time-and-Finance_NL.xlsx   Nederlands
  Team-Time-and-Finance_RU.xlsx   Русский
  Team-Time-and-Finance_FA.xlsx   فارسی
  Team-Time-and-Finance_UR.xlsx   اردو
  Team-Time-and-Finance_HI.xlsx   हिन्दी
  Team-Time-and-Finance_ZH.xlsx   中文
  Team-Time-and-Finance_ID.xlsx   Bahasa Indonesia
  Team-Time-and-Finance_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
