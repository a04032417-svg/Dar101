Production and Approvals
Production pipeline and client approvals for every brand you manage

FILES
  Production-and-Approvals_EN.xlsx   English
  Production-and-Approvals_AR.xlsx   العربية
  Production-and-Approvals_FR.xlsx   Français
  Production-and-Approvals_ES.xlsx   Español
  Production-and-Approvals_DE.xlsx   Deutsch
  Production-and-Approvals_IT.xlsx   Italiano
  Production-and-Approvals_PT.xlsx   Português
  Production-and-Approvals_TR.xlsx   Türkçe
  Production-and-Approvals_NL.xlsx   Nederlands
  Production-and-Approvals_RU.xlsx   Русский
  Production-and-Approvals_FA.xlsx   فارسی
  Production-and-Approvals_UR.xlsx   اردو
  Production-and-Approvals_HI.xlsx   हिन्दी
  Production-and-Approvals_ZH.xlsx   中文
  Production-and-Approvals_ID.xlsx   Bahasa Indonesia
  Production-and-Approvals_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
