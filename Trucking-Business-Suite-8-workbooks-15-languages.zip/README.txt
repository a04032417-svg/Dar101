Trucking Business Suite
Know your real profit on every load, truck and lane – and get paid on time

WORKBOOKS
  01 - Loads, Rates and Dispatch: Know what every load earns before you book it
  02 - Invoicing, Collections and Factoring: Get paid faster and see what slow brokers cost
  03 - Fuel and Fuel Tax by Region: Know what every litre costs and what you owe
  04 - Trucks, Trailers and Maintenance: Know which truck costs you money before it breaks down
  05 - Drivers, Pay and Settlements: Pay every driver right and see what each one earns
  06 - Compliance, Safety and Documents: Never dispatch a truck on an expired paper again
  07 - Costs, Cost per Km and Lane Profit: Know what a km costs and which lanes lose money
  08 - Finance, Cash Flow, Taxes and Growth: Know your profit, your cash and the next truck decision

Each folder holds the workbook in 15 languages and an English copy full of sample data.
Standard .xlsx files for Microsoft Excel and LibreOffice Calc. No macros. Personal use licence for one business.
