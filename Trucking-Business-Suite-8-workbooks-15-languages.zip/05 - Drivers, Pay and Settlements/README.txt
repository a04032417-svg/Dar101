Drivers, Pay and Settlements
Pay every driver right and see what each one earns

FILES
  Drivers-Pay-and-Settlements_EN.xlsx   English
  Drivers-Pay-and-Settlements_AR.xlsx   العربية
  Drivers-Pay-and-Settlements_FR.xlsx   Français
  Drivers-Pay-and-Settlements_ES.xlsx   Español
  Drivers-Pay-and-Settlements_DE.xlsx   Deutsch
  Drivers-Pay-and-Settlements_IT.xlsx   Italiano
  Drivers-Pay-and-Settlements_PT.xlsx   Português
  Drivers-Pay-and-Settlements_TR.xlsx   Türkçe
  Drivers-Pay-and-Settlements_NL.xlsx   Nederlands
  Drivers-Pay-and-Settlements_RU.xlsx   Русский
  Drivers-Pay-and-Settlements_FA.xlsx   فارسی
  Drivers-Pay-and-Settlements_UR.xlsx   اردو
  Drivers-Pay-and-Settlements_HI.xlsx   हिन्दी
  Drivers-Pay-and-Settlements_ZH.xlsx   中文
  Drivers-Pay-and-Settlements_ID.xlsx   Bahasa Indonesia
  Drivers-Pay-and-Settlements_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
