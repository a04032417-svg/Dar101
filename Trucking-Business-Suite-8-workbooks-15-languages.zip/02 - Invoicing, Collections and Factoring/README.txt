Invoicing, Collections and Factoring
Get paid faster and see what slow brokers cost

FILES
  Invoicing-Collections-and-Factoring_EN.xlsx   English
  Invoicing-Collections-and-Factoring_AR.xlsx   العربية
  Invoicing-Collections-and-Factoring_FR.xlsx   Français
  Invoicing-Collections-and-Factoring_ES.xlsx   Español
  Invoicing-Collections-and-Factoring_DE.xlsx   Deutsch
  Invoicing-Collections-and-Factoring_IT.xlsx   Italiano
  Invoicing-Collections-and-Factoring_PT.xlsx   Português
  Invoicing-Collections-and-Factoring_TR.xlsx   Türkçe
  Invoicing-Collections-and-Factoring_NL.xlsx   Nederlands
  Invoicing-Collections-and-Factoring_RU.xlsx   Русский
  Invoicing-Collections-and-Factoring_FA.xlsx   فارسی
  Invoicing-Collections-and-Factoring_UR.xlsx   اردو
  Invoicing-Collections-and-Factoring_HI.xlsx   हिन्दी
  Invoicing-Collections-and-Factoring_ZH.xlsx   中文
  Invoicing-Collections-and-Factoring_ID.xlsx   Bahasa Indonesia
  Invoicing-Collections-and-Factoring_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
