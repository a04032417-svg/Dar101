Fuel and Fuel Tax by Region
Know what every litre costs and what you owe

FILES
  Fuel-and-Fuel-Tax-by-Region_EN.xlsx   English
  Fuel-and-Fuel-Tax-by-Region_AR.xlsx   العربية
  Fuel-and-Fuel-Tax-by-Region_FR.xlsx   Français
  Fuel-and-Fuel-Tax-by-Region_ES.xlsx   Español
  Fuel-and-Fuel-Tax-by-Region_DE.xlsx   Deutsch
  Fuel-and-Fuel-Tax-by-Region_IT.xlsx   Italiano
  Fuel-and-Fuel-Tax-by-Region_PT.xlsx   Português
  Fuel-and-Fuel-Tax-by-Region_TR.xlsx   Türkçe
  Fuel-and-Fuel-Tax-by-Region_NL.xlsx   Nederlands
  Fuel-and-Fuel-Tax-by-Region_RU.xlsx   Русский
  Fuel-and-Fuel-Tax-by-Region_FA.xlsx   فارسی
  Fuel-and-Fuel-Tax-by-Region_UR.xlsx   اردو
  Fuel-and-Fuel-Tax-by-Region_HI.xlsx   हिन्दी
  Fuel-and-Fuel-Tax-by-Region_ZH.xlsx   中文
  Fuel-and-Fuel-Tax-by-Region_ID.xlsx   Bahasa Indonesia
  Fuel-and-Fuel-Tax-by-Region_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
