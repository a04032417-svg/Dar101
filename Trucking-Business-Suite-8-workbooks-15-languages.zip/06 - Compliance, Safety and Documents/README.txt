Compliance, Safety and Documents
Never dispatch a truck on an expired paper again

FILES
  Compliance-Safety-and-Documents_EN.xlsx   English
  Compliance-Safety-and-Documents_AR.xlsx   العربية
  Compliance-Safety-and-Documents_FR.xlsx   Français
  Compliance-Safety-and-Documents_ES.xlsx   Español
  Compliance-Safety-and-Documents_DE.xlsx   Deutsch
  Compliance-Safety-and-Documents_IT.xlsx   Italiano
  Compliance-Safety-and-Documents_PT.xlsx   Português
  Compliance-Safety-and-Documents_TR.xlsx   Türkçe
  Compliance-Safety-and-Documents_NL.xlsx   Nederlands
  Compliance-Safety-and-Documents_RU.xlsx   Русский
  Compliance-Safety-and-Documents_FA.xlsx   فارسی
  Compliance-Safety-and-Documents_UR.xlsx   اردو
  Compliance-Safety-and-Documents_HI.xlsx   हिन्दी
  Compliance-Safety-and-Documents_ZH.xlsx   中文
  Compliance-Safety-and-Documents_ID.xlsx   Bahasa Indonesia
  Compliance-Safety-and-Documents_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
