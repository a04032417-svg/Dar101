Loads, Rates and Dispatch
Know what every load earns before you book it

FILES
  Loads-Rates-and-Dispatch_EN.xlsx   English
  Loads-Rates-and-Dispatch_AR.xlsx   العربية
  Loads-Rates-and-Dispatch_FR.xlsx   Français
  Loads-Rates-and-Dispatch_ES.xlsx   Español
  Loads-Rates-and-Dispatch_DE.xlsx   Deutsch
  Loads-Rates-and-Dispatch_IT.xlsx   Italiano
  Loads-Rates-and-Dispatch_PT.xlsx   Português
  Loads-Rates-and-Dispatch_TR.xlsx   Türkçe
  Loads-Rates-and-Dispatch_NL.xlsx   Nederlands
  Loads-Rates-and-Dispatch_RU.xlsx   Русский
  Loads-Rates-and-Dispatch_FA.xlsx   فارسی
  Loads-Rates-and-Dispatch_UR.xlsx   اردو
  Loads-Rates-and-Dispatch_HI.xlsx   हिन्दी
  Loads-Rates-and-Dispatch_ZH.xlsx   中文
  Loads-Rates-and-Dispatch_ID.xlsx   Bahasa Indonesia
  Loads-Rates-and-Dispatch_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
