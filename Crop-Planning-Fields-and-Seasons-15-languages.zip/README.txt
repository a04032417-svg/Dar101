Crop Planning, Fields and Seasons
Plan fields, crops, rotation, seed and margin for the season

FILES
  Crop-Planning-Fields-and-Seasons_EN.xlsx   English
  Crop-Planning-Fields-and-Seasons_AR.xlsx   العربية
  Crop-Planning-Fields-and-Seasons_FR.xlsx   Français
  Crop-Planning-Fields-and-Seasons_ES.xlsx   Español
  Crop-Planning-Fields-and-Seasons_DE.xlsx   Deutsch
  Crop-Planning-Fields-and-Seasons_IT.xlsx   Italiano
  Crop-Planning-Fields-and-Seasons_PT.xlsx   Português
  Crop-Planning-Fields-and-Seasons_TR.xlsx   Türkçe
  Crop-Planning-Fields-and-Seasons_NL.xlsx   Nederlands
  Crop-Planning-Fields-and-Seasons_RU.xlsx   Русский
  Crop-Planning-Fields-and-Seasons_FA.xlsx   فارسی
  Crop-Planning-Fields-and-Seasons_UR.xlsx   اردو
  Crop-Planning-Fields-and-Seasons_HI.xlsx   हिन्दी
  Crop-Planning-Fields-and-Seasons_ZH.xlsx   中文
  Crop-Planning-Fields-and-Seasons_ID.xlsx   Bahasa Indonesia
  Crop-Planning-Fields-and-Seasons_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
