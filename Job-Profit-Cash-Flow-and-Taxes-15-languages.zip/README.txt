Job Profit, Cash Flow and Taxes
Job profit, cash flow, taxes and growth for cleaning businesses

FILES
  Job-Profit-Cash-Flow-and-Taxes_EN.xlsx   English
  Job-Profit-Cash-Flow-and-Taxes_AR.xlsx   العربية
  Job-Profit-Cash-Flow-and-Taxes_FR.xlsx   Français
  Job-Profit-Cash-Flow-and-Taxes_ES.xlsx   Español
  Job-Profit-Cash-Flow-and-Taxes_DE.xlsx   Deutsch
  Job-Profit-Cash-Flow-and-Taxes_IT.xlsx   Italiano
  Job-Profit-Cash-Flow-and-Taxes_PT.xlsx   Português
  Job-Profit-Cash-Flow-and-Taxes_TR.xlsx   Türkçe
  Job-Profit-Cash-Flow-and-Taxes_NL.xlsx   Nederlands
  Job-Profit-Cash-Flow-and-Taxes_RU.xlsx   Русский
  Job-Profit-Cash-Flow-and-Taxes_FA.xlsx   فارسی
  Job-Profit-Cash-Flow-and-Taxes_UR.xlsx   اردو
  Job-Profit-Cash-Flow-and-Taxes_HI.xlsx   हिन्दी
  Job-Profit-Cash-Flow-and-Taxes_ZH.xlsx   中文
  Job-Profit-Cash-Flow-and-Taxes_ID.xlsx   Bahasa Indonesia
  Job-Profit-Cash-Flow-and-Taxes_EN_DEMO-sample-data.xlsx   English copy filled with sample data, to see every feature working

HOW TO START
  1. Open the file in your language and read the Start sheet.
  2. Type your settings on the Start sheet (yellow cells).
  3. Type your own data in the white cells; gray cells calculate by themselves.
  4. Choose a value from the drop-downs wherever a cell offers one.

FILE FORMAT
  Standard .xlsx files for Microsoft Excel and LibreOffice Calc (tested in LibreOffice Calc). No macros.
  The formulas calculate when the file opens; if your app asks, allow it to update.

Personal use licence: one business may use the files; please do not resell or share them.
